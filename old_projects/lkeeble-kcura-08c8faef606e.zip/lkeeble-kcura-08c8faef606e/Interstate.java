public class Interstate
{
    String nameStr;
	
    public Interstate(String nameStr)
    {
            this.nameStr = nameStr;
    }


    public Integer getNumber()
    {
            String nameNoPrefix = nameStr.substring(2); // Remove I-

            return Integer.parseInt(nameNoPrefix);
    }


    @Override
    public String toString()
    {
            return nameStr;
    }


    @Override
    public boolean equals(Object o)
    {
        if (! (o instanceof Interstate))
        {
            return false;
        }

        Interstate oInterstate = (Interstate)o;
        return oInterstate.nameStr.equals(this.nameStr);
    }


    public int hashCode()
    {
        return nameStr.hashCode();
    }
}