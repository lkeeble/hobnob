import java.lang.*;
import java.util.*;


public class Challenge
{
	public static void main(String[] args) 
	{
		if (args.length < 1)
		{	
			System.err.println("Usage: java Challenge <filename.txt>");
			return;
		}
		
		String cityDataFilename = args[0];
		List<City> cities = CityManager.readCityData(cityDataFilename);
		
		// Option 1
		CityManager.writeCitiesByPopulationToFile(cities);
		InterstateManager.writeInterstateCountByCityToFile(cities);
		System.out.println("Done writing option 1 files");

		// Option 2
		DegreeManager.writeCitiesByDegreeToFile(cities);
		System.out.println("Done writing option 2 file");
	}
}