import java.lang.*;
import java.util.*;
import java.io.*;


public class CityManager
{
	public static List<City> readCityData(String fileName)
	{
		List<City> cities = new ArrayList<City>();
		try
		{
			FileInputStream fis = new FileInputStream(fileName);
			DataInputStream dis = new DataInputStream(fis);
			BufferedReader br = new BufferedReader(new InputStreamReader(dis));
			String strLine;
			
			while ((strLine = br.readLine()) != null)   
			{
				String[] tokens = strLine.split("\\|"); // Java split string is a RegEx so we need to escape the pipe
				String populationStr = tokens[0];
				String name = tokens[1];
				String state = tokens[2];
				String delimitedInterstateStr = tokens[3];
				
				City city = new City(populationStr, name, state, delimitedInterstateStr);
				cities.add(city);
			}
			fis.close();
		}
		catch (Exception ex)
		{
			throw new RuntimeException(ex);
		}		
		
		return cities;
	}
	
	
	static Comparator<City> cityNameStateAlphabeticalComparator
			= new Comparator<City>() 
	{
 	    public int compare(City city1, City city2) 
		{
			if (city1.getNameLC().equalsIgnoreCase(city2.getNameLC()))
			{
				return city1.state.compareTo(city2.state);
			}
			
			return city1.getNameLC().compareTo(city2.getNameLC());
	    }
	};	


    static Comparator<City> cityStateNameAlphabeticalComparator
            = new Comparator<City>()
    {
         public int compare(City city1, City city2)
        {
            if (city1.getStateLC().equalsIgnoreCase(city2.getStateLC()))
            {
                return city1.getNameLC().compareTo(city2.getNameLC());
            }

            return city1.getStateLC().compareTo(city2.getStateLC());
        }
    };


	private static TreeMap<Integer, Set<City>> getCitiesByPopulationMap(List<City> cities)
	{
		TreeMap<Integer, Set<City>> populationCityMap = new TreeMap<Integer, Set<City>>(descendingIntegerComparator);
		
		for (City city : cities)
		{
			Set<City> citySet;
			if (!populationCityMap.containsKey(city.population))
			{
				citySet = new TreeSet<City>(cityStateNameAlphabeticalComparator);
				populationCityMap.put(city.population, citySet);
			}
			else
			{
				citySet = populationCityMap.get(city.population);
			}
			
			citySet.add(city);
		}
		
		return populationCityMap;
	}
	
	
	private static Comparator<Integer> descendingIntegerComparator = new Comparator<Integer>() 
	{
		public int compare(Integer i1, Integer i2)
		{
			return i2.compareTo(i1);
		}
	};

	
	public static void writeCitiesByPopulationToFile(List<City> cities)
	{
		String fileName = "Cities_By_Population.txt";
		
		TreeMap<Integer, Set<City>> populationCityMap = getCitiesByPopulationMap(cities);
		
		try
		{
			PrintWriter writer = new PrintWriter(new FileOutputStream(fileName, false));
			
			for (Integer population : populationCityMap.keySet())
			{
				writer.println(population);
				writer.println();
				
				for (City city : populationCityMap.get(population))
				{
					city.sortInterstatesByNumberAscending();
					writer.println(getCityByPopulationData(city));
					writer.println();
				}
			}
			
			writer.close();
		}
		catch (Exception ex)
		{
			System.err.println("Error: " + ex.getMessage());
		}		
	}
	
	
	private static String getCityByPopulationData(City city)
	{
		StringBuilder sb = new StringBuilder();
		sb.append(city.name);
		sb.append(", ");
		sb.append(city.state);
		sb.append("\n");
		sb.append("Interstates: ");
		
		sb.append(InterstateManager.getInterstatesCommaSeparated(city.interstates));
		
		return sb.toString();
	}
}
