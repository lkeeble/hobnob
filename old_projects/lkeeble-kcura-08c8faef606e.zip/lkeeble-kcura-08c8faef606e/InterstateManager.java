import java.lang.*;
import java.util.*;
import java.io.*;


public class InterstateManager
{
	public static Comparator<Interstate> byNumberAscendingComparator = 
	new Comparator<Interstate>()
	{
		public int compare(Interstate interstate1, Interstate interstate2)
		{
			return interstate1.getNumber().compareTo(interstate2.getNumber());
		}
	};
	
	
	public static List<Interstate> getInterstateList(String semicolonDelimitedList)
	{
		String[] tokens = semicolonDelimitedList.split(";");
		List<Interstate> interstateList = new ArrayList<Interstate>();
		
		for (String token : tokens)
		{
			Interstate interstate = new Interstate(token);
			interstateList.add(interstate);
		}
		
		return interstateList;
	}
	
	
	public static void sortByNumberAscending(List<Interstate> interstateList)
	{
		Collections.sort(interstateList, byNumberAscendingComparator);
	}
	
	
	public static String getInterstatesCommaSeparated(List<Interstate> interstates)
	{
		StringBuilder sb = new StringBuilder();
		
		boolean isFirst = true;
		for (Interstate interstate : interstates)
		{
			if (!isFirst)
			{
				sb.append(", ");
			}
			sb.append(interstate.nameStr);
			
			isFirst = false;
		}
		
		return sb.toString();
	}
	
	
	public static void writeInterstateCountByCityToFile(List<City> cities)
	{
		String fileName = "Interstates_By_City.txt";
		Map<Interstate, Integer> interstateCountMap = getInterstateCountMap(cities);
		
		try
		{
			PrintWriter writer = new PrintWriter(new FileOutputStream(fileName, false));
			
			for (Interstate interstate : interstateCountMap.keySet())
			{
				writer.print(interstate.nameStr);
				int count = interstateCountMap.get(interstate);
				writer.print(" ");
				writer.print(count);
				writer.println();
			}
			
			writer.close();
		}
		catch (Exception ex)
		{
			throw new RuntimeException(ex);
		}		
	}
	
	
	private static Map<Interstate, Integer> getInterstateCountMap(List<City> cities)
	{
		Map<Interstate, Integer> interstateCountMap = new TreeMap<Interstate, Integer>(byNumberAscendingComparator);
	
		for (City city : cities)
		{
			for (Interstate interstate : city.interstates)
			{
				if (!interstateCountMap.containsKey(interstate))
				{
					interstateCountMap.put(interstate, 1);
				}
				else
				{
					Integer currentCount = interstateCountMap.get(interstate);
					Integer newCount = currentCount + 1;
					interstateCountMap.put(interstate, newCount);
				}
			}
		}
		
		return interstateCountMap;
	}
}