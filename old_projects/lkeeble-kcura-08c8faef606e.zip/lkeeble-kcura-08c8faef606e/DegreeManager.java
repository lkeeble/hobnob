import java.util.*;
import java.io.*;


public class DegreeManager
{
    public static String getResults(List<City> cities)
    {
        DegreeCalculator degreeCalculator = new DegreeCalculator(cities);

        Set<City> seedCities = new HashSet<City>();
        City seedCity;
        for (City city : cities)
        {
            if (city.name.equalsIgnoreCase("chicago"))
            {
                    seedCity = city;
                    seedCities.add(seedCity);
                    break;
            }
        }

        if (seedCities.isEmpty())
        {
                throw new RuntimeException("No seed cities defined");
        }

        degreeCalculator.fillDegreeCityMapExcludingProcessed(0, seedCities);

        // The example file provided doesn't contain any unlinked cities, but it could happen so handle it per the instructions.
        degreeCalculator.addUnlinkedCities();

                String results = degreeCalculator.getResults();

                return results;
    }
	
	
    public static void writeCitiesByDegreeToFile(List<City> cities)
    {
        String results = getResults(cities);
        String fileName = "Degrees_From_Chicago.txt";

        try
        {
            PrintWriter writer = new PrintWriter(new FileOutputStream(fileName, false));
            writer.println(results);

            writer.close();
        }
        catch (FileNotFoundException ex)
        {
            throw new RuntimeException(ex);
        }		
    }
}