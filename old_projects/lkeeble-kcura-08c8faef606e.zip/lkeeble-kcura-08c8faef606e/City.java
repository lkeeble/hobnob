import java.lang.*;
import java.util.*;


public class City
{
	int population; // In hundreds of thousands
	String name;
	String state;
	List<Interstate> interstates;
	

	public City(String populationStr, String name, String state, String delimitedInterstateStr)
	{
		this.population = Integer.parseInt(populationStr);
		this.name = name;
		this.state = state;
		this.interstates = InterstateManager.getInterstateList(delimitedInterstateStr);
	}

	
	public String toString()
	{
		StringBuilder sb = new StringBuilder();
		sb.append("Name:");
		sb.append(name);
		sb.append(" State:");
		sb.append(state);
		sb.append(" Population (100k):");
		sb.append(population);
		sb.append(" Interstates:");
		
		boolean isFirst = true;
		for (Interstate interstate : interstates)
		{	
			if (!isFirst)
			{
				sb.append(" ");
			}
			sb.append(interstate.nameStr);
			isFirst = false;
		}
		
		return sb.toString();
	}
	
	
	public void sortInterstatesByNumberAscending()
	{
		InterstateManager.sortByNumberAscending(this.interstates);
	}
	
	
	public String getNameLC()
	{
		return name.toLowerCase();
	}
	
	
        public String getStateLC()
        {
            return state.toLowerCase();
        }


	public String getKey()
	{
		return name + ", " + state;
	}
	
	
        @Override
	public boolean equals(Object o)
	{
            if (! (o instanceof City))
            {
                return false;
            }

            City oCity = (City)o;

            return oCity.getKey().equals(this.getKey());
	}
	
	
        @Override
	public int hashCode()
	{
            return getKey().hashCode();
	}
}
