import java.lang.*;
import java.util.*;


public class DegreeCalculator
{
	List<City> cities;
	Map<Interstate, Set<City>> interstateCityMap;
	Map<City, Set<Interstate>> cityInterstateMap;
	Map<Integer, Set<City>> degreeCityMap;
	Set<City> processedCities = new HashSet<City>();
	
	
	public DegreeCalculator(List<City> cities)
	{
		this.cities = cities;
		this.degreeCityMap = new TreeMap<Integer, Set<City>>(integerDescendingComparator);
		
		initMaps();
	}


    private static Comparator<Integer> integerDescendingComparator = new Comparator<Integer>() {
        public int compare(Integer integer1, Integer integer2) {
            return integer2.compareTo(integer1);
        }
    };
	
	
	private void initMaps()
	{
		interstateCityMap = new HashMap<Interstate, Set<City>>();
		cityInterstateMap = new HashMap<City, Set<Interstate>>();
		
		for (City city : cities)
		{
			Set<Interstate> interstateSet = new HashSet<Interstate>(city.interstates);
			cityInterstateMap.put(city, interstateSet);
			
			for (Interstate interstate : city.interstates)
			{
				Set<City> citySet;
				if (!interstateCityMap.containsKey(interstate))
				{
					citySet = new HashSet<City>();
					interstateCityMap.put(interstate, citySet);
				}
				else
				{
					citySet = interstateCityMap.get(interstate);
				}
				citySet.add(city);
			}
		}
	}
	
	
	public void fillDegreeCityMapExcludingProcessed(int degree, Set<City> citiesToProcess)
	{
		Set<City> citiesForDegree = new TreeSet<City>(CityManager.cityNameStateAlphabeticalComparator);
		Set<City> citiesToProcessNext = new HashSet<City>();
		for (City city : citiesToProcess)
		{
			if (!processedCities.contains(city))
			{
				citiesForDegree.add(city);
				citiesToProcessNext.addAll(getCitiesDirectlyConnectedExcludingProcessed(city));
				processedCities.add(city);
			}
		}
		
		degreeCityMap.put(degree, citiesForDegree);
		
		if (citiesToProcessNext.size() == 0)
		{
			return;
		}
		
		fillDegreeCityMapExcludingProcessed(degree + 1, citiesToProcessNext);
	}


    public void addUnlinkedCities()
    {
        Set<City> linkedCities = new HashSet<City>();
        Set<City> unlinkedCities = new HashSet<City>();

        for (Map.Entry<Integer, Set<City>> entry : degreeCityMap.entrySet())
        {
            linkedCities.addAll(entry.getValue());
        }

        for (City city : cities)
        {
            if (!linkedCities.contains(city))
            {
                unlinkedCities.add(city);
            }
        }

        degreeCityMap.put(-1, unlinkedCities);
    }
	
	
	private Set<City> getCitiesDirectlyConnectedExcludingProcessed(City city)
	{
		Set<Interstate> interstates = cityInterstateMap.get(city);
		Set<City> citiesDirectlyConnected = new HashSet<City>();
		for (Interstate interstate : interstates)
		{
			for (City cityForInterstate : interstateCityMap.get(interstate))
			{
				if (!processedCities.contains(cityForInterstate) && !cityForInterstate.equals(city))
				{
					citiesDirectlyConnected.add(cityForInterstate);
				}
			}
		}
		
		return citiesDirectlyConnected;
	}
	
	
	public String getResults()
	{
		StringBuilder sb = new StringBuilder();
		
		for (Integer degree : degreeCityMap.keySet())
		{
			for (City city : degreeCityMap.get(degree))
			{
				sb.append(degree);
				sb.append(" ");
				sb.append(city.name);
				sb.append(", ");
				sb.append(city.state);
                sb.append("\n");
			}
		}
		
		return sb.toString();
	}
}