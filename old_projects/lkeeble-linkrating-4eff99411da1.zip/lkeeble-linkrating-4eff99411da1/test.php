<html>
<head>
<title> PHP Test Script </title>
</head>
<body>
<?php
//phpinfo( );
//$url = "http://www.foo.com";
$url = "http://a";

if (!preg_match('/(https?:\/\/)[-A-Z0-9+&@#\/%?=~_|!:,.;]*[A-Z0-9+&@#\/%=~_|]$/i', $url))
{
    print("no match");
}
else
{
    print("match");
}
?>
</body>
</html>