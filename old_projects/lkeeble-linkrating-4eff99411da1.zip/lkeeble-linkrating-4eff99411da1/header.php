<link rel="stylesheet" type="text/css" href="linkrating.css" />
