<?php

class Constants
{
    public static $HOSTNAME = 'localhost';
    public static $USERNAME = 'root';
    public static $PASSWORD = 'austin';
    public static $DBNAME = 'linkrating';
}
?>
