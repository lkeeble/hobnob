<?php
    function redirect($url)
    {
        header('Location: ' . $url);
        exit();
    }

    function getValOrNbspIfBlank($val)
    {
        if (!empty($val))
        {
            return $val;
        }
        else
        {
            return "&nbsp;";
        }
    }
?>