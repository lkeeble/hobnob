<?php
    include_once('Bootstrap.php');
    include_once('LinkTable.php');
    include_once('utils.php');
    include_once('header.php');
		
	$msg = "";

    if (isset($_POST['deleteLinkEvent']))
    {
        $action = "post";
        $linkId = $_POST['linkId']; 
		LinkTable::deleteLink($linkId);
		//$msg = "Deleted link for link_id=" . $linkId;
	}
?>

<html>
	<head>
	<?php include_once('header.php'); ?>
	<title>Links</title>
	<script>
	function handleDelete(linkId)
	{
		document.mainForm.linkId.value = linkId;
	}
	</script>
	</head>

	<body>
		<?php // left hand margin ?>
		<table width="100%">
			<tr><td width="20"></td>
				<td>
					<table border="0" width="100%">
						<form name="mainForm" method="post">
						<tr><td nowrap><span class="title">Links</span></h3>&nbsp;&nbsp;&nbsp; <a href="AddLink.php">Add Link</a></td></tr>
						<?php 
						if (!empty($msg))  
						{ 
							echo $msg ;
						}
						?>
						<tr><td height="20"></td></tr>
						<tr>
							<td>
								<input type="hidden" name="linkId" value="">
								<table border="1">
								<?php
									$tagRows = LinkTable::getTagRowsForLink(1);
									//var_dump($tagRows);

									$rows = LinkTable::getAllLinkRows();
									foreach ($rows as $row)
									{
										$linkVal = getValOrNbspIfBlank($row['url']);
										$linkId = $row['link_id'];
										$shortDescriptionVal = getValOrNbspIfBlank($row['short_description']);
										$longDescriptionVal = getValOrNbspIfBlank($row['long_description']);
						?>
										<tr>
											<td width="20%">
												<b>
												<?php print($linkVal); ?>
												</b>
											</td>
											<td width="20%">
												<?php print($shortDescriptionVal); ?>
											</td>
											<td width="50%">
												<?php print ($longDescriptionVal); ?>
											</td>
											<td>
												<input type="submit" name="deleteLinkEvent" value="Delete" onclick="handleDelete('<?php echo $linkId ?>')">
											</td>
										</tr>
								<?php } ?>
								</table>
							</td>
						</tr>
						</form>
					</table>
				</td>
			</tr>
		</table>
	</body>
</html>
