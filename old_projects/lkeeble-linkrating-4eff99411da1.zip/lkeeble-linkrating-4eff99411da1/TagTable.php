<?php
include('./Constants');

class TagTable
{
    public static function deleteTag($tagId)
    {
        $db = DbUtil::getDbHandle();
        $stmt = $db->prepare("delete from Tag  where tag_id = :url");
        $stmt->bindParam(':tag_id', $tagId);

        $stmt->execute();
    }


    public static function insertTag($name)
    {
        $db = DbUtil::getDbHandle();
        $stmt = $db->prepare("insert into tag (name) values (:name)");
        $stmt->bindParam(':name', $name);

        $stmt->execute();
    }


    public static function getOrInsertTagByName($tagName)
    {
                if (TagTable::existsWithName($tagName))
                {
                    $tagRow = TagTable::getTagByName($tagName);
                }
                else
                {
                    TagTable::insertTag($tagName);
                    $tagRow = TagTable::getTagByName($tagName);
                }
                
                return $tagRow;
    }


    public static function getTagById($tagId)
    {
        $db = DbUtil::getDbHandle();
        $stmt = $db->prepare('select * from Tag where tag_id = :tag_id');
        $stmt->bindParam(':tag_id', $tagId);
        $stmt->execute();

        return $stmt->fetch();
    }


    public static function getTagByName($name)
    {
        $db = DbUtil::getDbHandle();
        $stmt = $db->prepare('select * from Tag where name = :name');
        $stmt->bindParam(':name', $name);
        $stmt->execute();

        return $stmt->fetch();
    }


    public static function getAllTagRows()
    {
        $db = DbUtil::getDbHandle();
        $stmt = $db->prepare('select * from Tag');
        $stmt->execute();

        return $stmt->fetchAll();
    }


    public static function existsWithName($name)
    {
        $db = DbUtil::getDbHandle();
        $stmt = $db->prepare("select * from Tag where name = :name");
        $stmt->bindParam(':name', $name);
        $stmt->execute();

        return $stmt->fetch() !== false;
    }
}
?>