<?php
class DbUtil
{
    private static $_db;

    public static function getDbHandle()
    {
        $connectString = "mysql:host=" . Constants::$HOSTNAME . ";dbname=" . Constants::$DBNAME;

        if (empty (DbUtil::$_db))
        {
            try
            {
                DbUtil::$_db = new PDO($connectString, Constants::$USERNAME, Constants::$PASSWORD);
                DbUtil::$_db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            }
            catch(PDOException $ex)
            {
                echo $ex->getMessage;
            }
        }

        return DbUtil::$_db;
    }
}
?>
