<?php

class LinkTagTable
{
    public static function insert($linkId, $tagId)
    {
        $db = DbUtil::getDbHandle();
        $stmt = $db->prepare("insert into linktag (link_id, tag_id) values (:link_id, :tag_id");
        $stmt->bindParam(':link_id', $linkId);
        $stmt->bindParam(':tag_id', $tagId);

        $stmt->execute();
    }


    public static function delete($linkId, $tagId)
    {
        $db = DbUtil::getDbHandle();
        $stmt = $db->prepare("delete from linktag where link_id = :link_id and tag_id = :tag_id");
        $stmt->bindParam(':link_id', $linkId);
        $stmt->bindParam(':tag_id', $tagId);

        $stmt->execute();
    }
}
?>
