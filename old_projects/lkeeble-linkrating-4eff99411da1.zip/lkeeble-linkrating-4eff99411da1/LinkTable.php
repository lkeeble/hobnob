<?php
class LinkTable
{
    public static function deleteLink($linkId)
    {
        $db = DbUtil::getDbHandle();
        
		$stmt = $db->prepare("delete from link  where link_id = :link_id");
        $stmt->bindParam(':link_id', $linkId);

        $stmt->execute();
    }


    public static function getTagRowsForLink($linkId)
    {
        $db = DbUtil::getDbHandle();
        $stmt = $db->prepare(
            "select tag.* from tag, link, linktag
             where tag.tag_id = linktag.tag_id
             and link.link_id = linktag.link_id
             and link.link_id = :link_id");

        $stmt->bindParam(':link_id', $linkId);
        $stmt->execute();

        return $stmt->fetchAll();
    }


    public static function insertLink($url, $shortDescription, $longDescription)
    {
        $db = DbUtil::getDbHandle();
        $stmt = $db->prepare("insert into link (url, short_description, long_description) values (:url, :short_description, :long_description)");
        $stmt->bindParam(':url', $url);
        $stmt->bindParam(':short_description', $shortDescription);
        $stmt->bindParam(':long_description', $longDescription);

        $stmt->execute();
    }
	
	
    public static function associateTagWithLink($linkId, $tagName)
    {
        $db = DbUtil::getDbHandle();
        $tagRows = LinkTable::getTagRowsForLink($linkId);
        if ($tagRows)
        {
            foreach ($tagRows as $tagRow)
            {
                if ($tagRow['name'] === $tagName)
                {
                    return;
                }

            }
            
            $linkRow = LinkTable::getLinkById($linkId);
            $tagRow = TagTable::getOrInsertTagByName($tagName);

            $tagId = $tagRow['tag_id'];
            LinkTagTable::insert($linkId, $tagId);
        }
    }


    public static function associateTagsWithLink($linkId, $tagNamesDesired)
    {
        $existingTagRows = LinkTable::getTagRowsForLink($linkId);

        foreach ($existingTagRows as $existingTagRow)
        {
            $existingTagName = $existingTagRow['name'];
            if (!array_key_exists($existingTagName, $tagNamesDesired))
            {
                LinkTable::disassociateTagWithLink($linkId, $existingTagName);
            }
        }
    }


    public static function getLinkById($link_id)
    {
        $db = DbUtil::getDbHandle();
        $stmt = $db->prepare('select * from link where link_id = :link_id');
        $stmt->bindParam(':link_id', $link_id);
        $stmt->execute();

        return $stmt->fetch();
    }


    public static function getAllLinkRows()
    {
        $db = DbUtil::getDbHandle();
        $stmt = $db->prepare('select * from link');
        $stmt->execute();
        
        return $stmt->fetchAll();
    }


    public static function existsWithUrl($url)
    {
        $db = DbUtil::getDbHandle();
        $stmt = $db->prepare("select * from link where url = :url");
        $stmt->bindParam(':url', $url);
        $stmt->execute();

        return $stmt->fetch() !== false;
    }
}
?>