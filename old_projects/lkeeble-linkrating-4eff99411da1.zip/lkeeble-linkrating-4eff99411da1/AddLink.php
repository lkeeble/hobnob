<?php
    include_once('Bootstrap.php');
    include_once('BootstrapSession.php');
    include_once('LinkTable.php');
    include_once('utils.php');
    
    $errorMessage = "";
    $action = "view";

//    $links = Link::getAllWithTagName('search');
//    var_dump($links);

    $url = 'http://';
    $shortDescription = '';
    $longDescription = '';
    $tags = '';

    if (isset($_POST['addLinkEvent']))
    {
        $action = "post";
        $url = trim($_POST['url'], "/");  // remove final "/", if any.
        $shortDescription = trim($_POST['shortDescription']);
        $longDescription = trim($_POST['longDescription']);
        $tags = trim($_POST['tags']);
        $tagWords = split("[\n\r\t ]+", $tags);

        if (empty($url))
        {
            $errorMessage = "The link's URL must not be blank.";
        }
        elseif (!preg_match('/(https?:\/\/)[-A-Z0-9+&@#\/%?=~_|!:,.;]*[A-Z0-9+&@#\/%=~_|]$/i', $url))
        {
            $errorMessage = "The link's URL does not appear to be formatted properly.";
        }
        elseif (empty($shortDescription) || strlen($shortDescription) < 5)
        {
            $errorMessage = "The link's short description is too short";
        }
        elseif (empty($tags))
        {
            $errorMessage = "You must add at least one tag";
        }
        elseif (LinkTable::existsWithUrl($url))
        {
            $errorMessage = "This link already exists.";
        }

        if (empty($errorMessage))
        {
            LinkTable::insertLink($url, $shortDescription, $longDescription);
        }
    }
    elseif (isset($_POST['viewLinkListEvent']))
    {
        redirect('ViewLinks.php');
    }
?>

<html>
    <body>
        <head>
            <title>Add a Link</title>
			<?php include_once('header.php'); ?>
        </head>

        <form name="mainForm" method="post">
        <table>
            <tr><td height="10" nowrap></td></tr>
            <tr>
                <td></td>
                <td>
                <?php
                    if ($action === 'post')
                    {
                        if (!empty($errorMessage))
                        {
                            print('<span class="errorMessage">');
                            print($errorMessage);
                            print ('</span>');
                        }
                        else
                        {
                            print('<span class="successMessage">');
                            print('A new link has been added.');
                            print ('</span>');
                        }
                    }
                ?>
                </td>
            </tr>
            <tr><td height="10" nowrap></td></tr>
            <tr>
                <td></td>
                <td><b><div class="title">Add a Link</div></b></td>
            </tr>
            <tr><td height="10" nowrap></td></tr>
            <tr>
                <td align="right">
                    <b>Address</b>:
                </td>
                <td>
                    <input type="text" size="100" name="url" value="<?php echo $url ?>"> <font color="blue"><b>(required)</b></font>
                </td>
            </tr>
            <tr><td height="10" nowrap></td></tr>
            <tr>
                <td align="right">
                    <b>Short Description:</b>
                </td>
                <td>
                    <input type="text" size="100" name="shortDescription" value="<?php echo $shortDescription; ?>"> <font color="blue"><b>(required)</b></font>
                </td>
            </tr>
            <tr><td height="10" nowrap></td></tr>
            <tr>
                <td align="right" valign="top">
                    <b>Long Description:</b>
                </td>
                <td>
                    <textarea cols="76" rows="10" name="longDescription"><?php echo $longDescription; ?></textarea>
                </td>
            </tr>
            <tr><td height="10" nowrap></td></tr>
            <tr>
                <td align="right">
                    <b>Tags:</b>
                </td>
                <td>
                    <input type="text" size="50" name="tags" value="<?php echo $tags; ?>"> <font color="blue"><b>(at least one tag required, comma-separated)</b></font>
                </td>
            </tr>
            <tr><td height="10" nowrap></td></tr>
            <tr>
                <td></td>
                <td>
                    <input type="submit" name="addLinkEvent" value = "Add Link">
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <input type="submit" name="viewLinkListEvent" value = "View All Links">
                </td>
            </tr>
        </table>
        </form>
    </body>
</html>
