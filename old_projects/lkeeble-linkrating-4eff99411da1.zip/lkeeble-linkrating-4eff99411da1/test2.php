<?php

include_once('BootstrapDb.php');
include_once('LinkTable.php');


$LinkTable = new LinkTable();
$LinkTable->addLink("www.google.com", "google home page");

$sql = 'SELECT * FROM link WHERE id = ?';

$result = $db->fetchAll($sql, 1);

print_r($result);

$today = date("l");
print("today: $today");

?>