<?php
session_start();

if(!isset($_SESSION['folder']))
{
    $_SESSION['folderId'] = 'root';
}
?>