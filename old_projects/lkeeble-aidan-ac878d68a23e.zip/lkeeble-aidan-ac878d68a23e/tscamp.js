function sendEmail(user,domain) {
        parent.location.href = "mailto:" + user + "\@" + domain;
}


<!-- Countdown Script by Virtual_Max             -->
<!-- http://come.to.vmax                         -->
<!-- please keep this comment unchanged if you use it  -->

// surrounded with anonymous function to keep local variables non-global.
(function() {
    var eventdate = new Date("June 23, 2013 14:00:00 CST");

    $(document).ready(countdown);

    function toStringZeroPad(n)
    {
        var s = "";
        if (n < 10)
        {
            s += "0";
        }

        return s + n.toString();
    }

    function countdown()
    {
        var d = new Date();
        var count = Math.floor((eventdate.getTime()-d.getTime())/1000);
        var seconds = toStringZeroPad(count%60);
        count = Math.floor(count/60);
        var minutes = toStringZeroPad(count%60);
        count = Math.floor(count/60);
        var hours = toStringZeroPad(count%24);
        count = Math.floor(count/24);
        var days = count;

        $displayElement = $('#countdown'); 
        $displayElement.text(days + ' days, ' + hours + ' hours, ' + minutes + ' mins, ' + seconds + ' seconds!');

        setTimeout(countdown, 500);
    }
})();
