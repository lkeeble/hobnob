<?php

	include_once("template.php");

	$pageInfo['title_short'] = "Shamrocks for Children";
	$pageInfo['title_long'] = "";

	pageHeader( $pageInfo );

?>

							<div align="center" style="font-family:'tahoma'">
								<span style="font-size:20pt;">"SHAMROCKS FOR CHILDREN"</span><br /><br />
								<span style="font-size:14pt;">to benefit the</span><br /><br />
								<span style="font-size:18pt;">Tourette Syndrome Camping Organization</span><br /><br />
								<span style="font-size:16pt;">Sunday, March 26, 2006</span><br /><br />
								<span style="font-size:14pt;">at Galvin's Public House</span><br /><br />
								<span style="font-size:14pt;">5901 W. Lawrence, Chicago</span><br /><br />
								<span style="font-size:16pt;">3 - 6 p.m.</span><br /><br />
								<span style="font-size:14pt;">Tickets - $25.00/ea</span><br /><br />
							</div>

							The Tourette Syndrome Camp Organization (A 501 (3) C non-profit organization ) operates a 5-day residential summer camp program for boys and girls ages 8 to 17 whose primary diagnosis is Tourette Syndrome and associated disorders ( Obsessive Compulsive Disorder and Attention Deficit Disorder).  Proceeds from this benefit will be used to provide scholarships for families in need to send their child and defer costs to provide a quality, positive camping experience.
							<br /><br />

<table border="0" cellspacing="5" width="100%">
	<tr>
		<td width="100"><strong>Name:</strong></td>
		<td style="border-bottom: 1px #000000 solid">&nbsp;</td>
	</tr>
	<tr>
		<td width="100"><strong>Address:</strong></td>
		<td style="border-bottom: 1px #000000 solid">&nbsp;</td>
	</tr>
	<tr>
		<td width="100"><strong>&nbsp;</strong></td>
		<td style="border-bottom: 1px #000000 solid">&nbsp;</td>
	</tr>
	<tr>
		<td width="100"><strong># of Tickets:</strong></td>
		<td>____________ ($25/ea)</td>
	</tr>
	<tr>
		<td width="100"><strong>Total:</strong></td>
		<td>____________</td>
	</tr>
	<tr>
		<td width="100"><br /></td>
		<td><br /></td>
	</tr>
	<tr>
		<td colspan="2"><strong>I cannot attend but would like to donate</strong> $___________</td>
	</tr>
</table>
<br />
All Donations are tax exempt to the extent of the law.

Please make checks payable to:
<br /><br />
<address>Tourette Syndrome Camp Organization<br />6933 N Kedzie #816<br />Chicago, IL 60645</address>

<? pageFooter( $pageInfo ); ?>