<?php
include_once("template.php");
$pageInfo['title_short'] = "Summer 2014 Camp Registration Online";
$pageInfo['title_long'] = "Summer 2014 Camp Registration Online";
pageHeader($pageInfo );
?>

&nbsp;<br />

<div id="wufoo-wt192b60nj0vc5">
Fill out my <a href="https://tourettecamp.wufoo.com/forms/wt192b60nj0vc5">online form</a>.
</div>
<script type="text/javascript">var wt192b60nj0vc5;(function(d, t) {
var s = d.createElement(t), options = {
'userName':'tourettecamp', 
'formHash':'wt192b60nj0vc5', 
'autoResize':true,
'height':'7776',
'async':true,
'host':'wufoo.com',
'header':'show', 
'ssl':true};
s.src = ('https:' == d.location.protocol ? 'https://' : 'http://') + 'wufoo.com/scripts/embed/form.js';
s.onload = s.onreadystatechange = function() {
var rs = this.readyState; if (rs) if (rs != 'complete') if (rs != 'loaded') return;
try { wt192b60nj0vc5 = new WufooForm();wt192b60nj0vc5.initialize(options);wt192b60nj0vc5.display(); } catch (e) {}};
var scr = d.getElementsByTagName(t)[0], par = scr.parentNode; par.insertBefore(s, scr);
})(document, 'script');</script>

<? pageFooter( $pageInfo ); ?>

