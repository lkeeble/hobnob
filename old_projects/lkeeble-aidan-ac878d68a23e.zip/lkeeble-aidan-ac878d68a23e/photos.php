<?php

	include_once("template.php");

	$pageInfo['title_short'] = "Summer Camp Photos";
	$pageInfo['title_long'] = "Summer Camp Photos";

	pageHeader( $pageInfo );

?>
<p>
Please scroll down to see some moments from camp!
</p>
<p>
You can view more pictures here:
</p>

<p id="link_list">
<a href="http://www.facebook.com/groups/156667161030448" target="_facebook">Camp Facebook Page</a> <br/>
<a href="http://www.flickr.com/photos/12580231@N08/" target="_blank">Flickr Photo Album</a> <br/>
<a href="http://tourettesyndromecampusa2009.shutterfly.com/#" target="_blank">Shutterfly Photo Album.</a>
</p>
<br/>


<h2>Summer Camp 2011</h2>

<div id="photogallery">
<img src="images/2011camp/3.jpg" width="400px" /><img src="images/2011camp/4.jpg" width="400px" />
<img src="images/2011camp/5.jpg" width="400px" /><img src="images/2011camp/6.jpg" width="400px" />
<img src="images/2011camp/9.jpg" width="400px" /><img src="images/2011camp/10.jpg" width="400px" />
<img src="images/2011camp/11.jpg" width="400px" /><img src="images/2011camp/12.jpg" width="400px" />
<img src="images/2011camp/13.jpg" width="400px" /><img src="images/2011camp/14.jpg" width="400px" />
<img src="images/2011camp/15.jpg" width="400px" /><img src="images/2011camp/16.jpg" width="400px" />
<img src="images/2011camp/1.jpg" width="400px" /><img src="images/2011camp/2.jpg" width="400px" />
<img src="images/2011camp/7.jpg" width="400px" /><img src="images/2011camp/8.jpg" width="400px" />


<br/>&nbsp;<br/>
<br/>&nbsp;<br/>

<h2>Summer Camp 2010</h2>

<img src="images/2010camp/DSCN0394.jpg" width="400px" /><img src="images/2010camp/DSCN0242.jpg" width="400px" />
<img src="images/2010camp/DSCN0464.jpg" width="400px" /><img src="images/2010camp/DSCN0286.jpg" width="400px" />
<img src="images/2010camp/DSCN0313.jpg" width="400px" /><img src="images/2010camp/DSCN0322.jpg" width="400px" />
<img src="images/2010camp/DSCN0337.jpg" width="400px" /><img src="images/2010camp/DSCN0359.jpg" width="400px" />
<img src="images/2010camp/DSCN0373.jpg" width="400px" /><img src="images/2010camp/DSCN0380.jpg" width="400px" />

<br/>&nbsp;<br/>
<br/>&nbsp;<br/>

<h2>Summer Camp 2009</h2>
<img src="images/2009camp/Forbes 11-29-08_1500 (Small).JPG" width="400px" /><img src="images/2009camp/Forbes 11-29-08_1534 (Small).JPG" width="400px" /> 
<img src="images/2009camp/Forbes 11-29-08_1505 (Small).JPG" width="400px" /><img src="images/2009camp/Forbes 11-29-08_1476 (Small).JPG" width="400px" />
<img src="images/2009camp/Forbes 11-29-08_1813 (Small).JPG" width="400px" /><img src="images/2009camp/Forbes 11-29-08_1823 (Small).JPG" width="400px" />
<img src="images/2009camp/Forbes 11-29-08_1655 (Small).JPG" width="400px" /><img src="images/2009camp/Forbes 11-29-08_1762 (Small).JPG" width="400px" />
<img src="images/2009camp/Forbes 11-29-08_1749 (Small).JPG" width="400px" /><img src="images/2009camp/Forbes 11-29-08_1712 (Small).JPG" width="400px" />
<img src="images/2009camp/Forbes 11-29-08_1705 (Small).JPG" width="400px" /><img src="images/2009camp/Forbes 11-29-08_1541 (Small).JPG" width="400px" />
<img src="images/2009camp/Forbes 11-29-08_1535 (Small).JPG" width="400px" /><img src="images/2009camp/Forbes 11-29-08_1641 (Small).JPG" width="400px" />
<img src="images/2009camp/Forbes 11-29-08_1624 (Small).JPG" width="400px" /><img src="images/2009camp/Forbes 11-29-08_1620 (Small).JPG" width="400px" />
<img src="images/2009camp/Forbes 11-29-08_1290 (Small).JPG" width="400px" />

<br/>&nbsp;<br/>
<br/>&nbsp;<br/>

<h2>Summer Camp 2007</h2>
<img src="images/camp/2007_p15_500px.jpg" width="400px" /><img src="images/camp/2007_p5_500px.jpg" width="400px" />
<img src="images/camp/2007_p13_500px.jpg" width="400px" /><img src="images/camp/2007_p2_500px.jpg" width="400px" />
<img src="images/camp/2007_p1_500px.jpg" width="400px" /><img src="images/camp/2007_p4_500px.jpg" width="400px" />
<img src="images/camp/2007_p6_500px.jpg" width="400px" /><img src="images/camp/2007_p7_500px.jpg" width="400px" />
<img src="images/camp/2007_p8_500px.jpg" width="400px" /><img src="images/camp/2007_p9_500px.jpg" width="400px" />
<img src="images/camp/2007_p10_500px.jpg" width="400px" /><img src="images/camp/2007_p11_500px.jpg" width="400px" />
<img src="images/camp/2007_p12_500px.jpg" width="400px" /><img src="images/camp/2007_p14_500px.jpg" width="400px" />
<img src="images/camp/2007_p17_500px.jpg" width="400px" /><img src="images/camp/2007_p3_500px.jpg" width="400px" />
<br/>
    
<br/>&nbsp;<br/>
<br/>&nbsp;<br/>

<h2>Summer Camp 2006</h2>
<img src="images/camp/2006_533.jpg" alt="" border="0" />
<img src="images/camp/2006_025.jpg" alt="" border="0" />
<img src="images/camp/2006_125.jpg" alt="" border="0" />
<img src="images/camp/2006_541.jpg" alt="" border="0" />
<img src="images/camp/2006_052.jpg" alt="" border="0" />
<img src="images/camp/2006_458.jpg" alt="" border="0" />
<img src="images/camp/2006_509.jpg" alt="" border="0" />
<img src="images/camp/2006_471.jpg" alt="" border="0" />

</div>

<?php pageFooter( $pageInfo ); ?>