<?php

	include_once("template.php");

	$pageInfo['title_short'] = "Articles";
	$pageInfo['title_long'] = "Articles";

	pageHeader( $pageInfo );

?>

<p id="link_list">
				<a href="docs/20090223_tribune_article.pdf" title="Chicago Tribune Article, Feb 23 2009">Chicago Tribune Article, Feb 23 2009 (PDF)</a>by Jason George
				<a href="campnurse.php" title="Camp Nurse Article">Camp Nurse Article</a>by Scott Williams
				<a href="myweekatcamp.php">My Week at Tourette Camp</a>by Jaime Biava
</p>

<?php pageFooter( $pageInfo ); ?>