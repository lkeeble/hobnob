<?php

	include_once("template.php");

	$pageInfo['title_short'] = "Welcome!";
	$pageInfo['title_long'] = "Welcome!";

	pageHeader( $pageInfo );
?>


<img class="floatleft border margin10px" src="images/2012frontpage/climb.jpg" width="200">
<h2>The Organization</h2>
<p>
The Tourette Syndrome Camp Organization (TSCO) is a 501 (c)(3) 
tax exempt non-profit organization dedicated to promoting camping opportunities for children with 
Tourette Syndrome (TS) and Obsessive Compulsive Disorder (OCD) and its associated disorders 
Attention Deficit/Hyperactivity Disorder (ADD/ADHD). 
</p>

<h2>The Program</h2>
<!-- <img class="floatright border margin10px" src="images/2011frontpage/4.jpg" width=400> -->
<img class="floatright border margin10px" src="images/2013frontpage/1005691_10151539669353983_1310159029_n.jpg" width="400">
<!-- <img class="floatright border margin10px" src="images/2013frontpage/1044046_10151539652703983_914809155_n.jpg" width="200"> -->

<p>
The Tourette Syndrome Camp USA, founded in 1994, is a residential camping program designed for girls and boys ages 8 - 16+ 
whose primary diagnosis is TS, and to a lesser degree, OCD and ADD/ADHD.
The goal of the camp is to allow children with TS an opportunity to meet other children, 
share similar experiences and coping mechanisms in a fun, safe and positive environment.
</p>
<p>
The TS camp is run concurrently with a traditional camp week. While there are separate cabins for the TS campers, all programming is done with the rest of the camp. 
However, we do have our own group time with the TS campers so they have an opportunity to share their experiences with each other. 
In addition, Camp Duncan is home to many medical camps such as ours which provide a safe, positive and understanding environment.
</p>

<p>
There is a nurse to handle medication and medical issues for the TS campers.
</p>
<p>
This year for our campers who are 16, we are adding a Couselor in Training Program CIT.  These campers wilbe given 
leadership opportunites that will help with a transition to possible future positions on our staff.
</p>
<p>
This is not a therapeutic program and the camp has some limitations in accepting children whose needs are beyond the scope of its design.  		
</p>
<p>
Campers must be able to handle routine daily living skills (i.e. dressing, self hygiene) and have the ability to function in a group setting.  While the program is modified to meet the 
needs of most children whose primary diagnosis is TS, experience has demonstrated that not every child with TS is capable of participating in the camp program.
</p>

<h2>The Staff</h2>
<img class="floatright border margin10px" src="images/2011frontpage/staff.jpg" width=500>
<!-- <img class="floatright border margin10px" src="images/2012frontpage/boy.jpg" width=200> -->
<p>
In addition to providing in-service training for the Camp Duncan staff, TSCO augments the Tourette camps with special TS volunteer counselors who either have 
TS/OCD/ADD or have experience in dealting with the disorders. Our staff includes medical and psychiatric professionals that have volunteered as well as high school 
and college students along with young adults who hace a desire to work with children and are positive role models. 
</p>
<p>
We are always looking for candidates to be counselors. 
<br>
If you are interested, please 
<a href="staff.php">apply for a staff position.</a>
</p>


</p>
<h2>Staff Bios</h2>

<h3 class="bio">Camp Director</h3>
<p>
Monica Newman has been on camp staff for 11 years.  
When she was 16 years old, she began her camp �career� as a junior counselor. Monica decided to become involved when her 
younger brother Sean (who is now also on staff) started attending camp. Monica became the Camp Director in the summer of 2011 after 
serving two years as Assistant Director. She is a Special Education teacher in a suburb of Chicago where she has given multiple 
in-service presentations about Tourette�s syndrome and has become her school districts resource person for Tourette�s syndrome. 
Monica graduated from Eastern Illinois University in 2009 with a Bachelor of Science degree in Special Education and is certified as a 
Learning Behavior Specialist 1. She is currently working towards a Master�s Degree at Concordia University Chicago. She will hold a 
graduate degree in Curriculum and Instruction (M.S. Ed) with an endorsement in English as a Second Language (ESL) in December 2013. 
Monica credits her brother as well as TS camp for her decision to pursue a degree and a career as a Special Education teacher. 
Watching her brother struggle through school pushed her to become an advocate for children with special needs. She looks forward 
to camp every summer and has joked that she is now a �lifer� with TS camp!
</p>

<h3 class="bio">Assistant Director</h3>
<p>
Marleen Martinez has been Assistant Camp Director for two years. She joined the camp staff four years ago as a young adult with TS. 
After reading a magazine article by TS advocate Neve Campbell, she self diagnosed herself at age 17. She has also been 
featured as part of the Family Portraits of Adults with TS in the Tourette Syndrome Association Newsletter. Marleen has a degree in 
Aeronautical & Astronautical Engineering from the University of Washington. She currently works for Lockheed Martin Space Systems 
Company on the Orion spacecraft for NASA. During the Fall of 2011, Marleen experienced one of her greatest accomplishments in life, 
watching the two GRAIL spacecraft she had been building and testing for 2 years launch from Cape Canaveral, Florida to begin their 
mission around moon. She invited numerous kids with TS from Florida to be her personal guests at the launch.
</p>

<h3 class="bio">Director of Camper Success</h3>
<p>
Sarah Matchen has been on camp staff since 2001, starting as a counselor and moving into her current position after earning 
her Masters in Social Work. Sarah has her LCSW and the 51 weeks of the year she is not at camp she works as a crisis therapist with 
children, adolescents and families while dreaming of being back at camp!
</p>

<!-- <img class="floatleft border margin10px" src="images/2012frontpage/goofy.jpg" width=300> -->
<img class="floatleft border margin10px" src="images/2013frontpage/969878_10151541035213983_1561753001_n.jpg" width=300>
<h2>The Facility</h2>
<p>
The Tourette Syndrome Camp USA is held at <a href="http://www.ymcacampduncan.org" target="_blank">YMCA Camp Duncan</a> 
which is located 30 miles north of Chicago.  Camp is home to other special needs such as burn and diabetic Camp. 
The facility features an Olympic size indoor swimming pool and a semi-private lake.  
Their caring staff assures a positive experience in a caring environment.
</p>

<div style="margin-top: 20px;">&nbsp;</div>

<?php schedule()?>

<!--
<table width="100%">
<tr>
	<td align="center">Eli (2006, Camper)</td>
	<td align="center">Eli (2011, Counselor)</td>
</tr>
<tr>
	<td>
		<img class="border margin10px" src="images/2009frontpage/eli_2006_75pct.JPG">
	</td>
	<td>
		<img class="border margin10px floatright" src="images/2009frontpage/eli_2011_56pct.JPG">
	</td>
</tr>
</table>
-->

<?php pageFooter( $pageInfo ); ?>
