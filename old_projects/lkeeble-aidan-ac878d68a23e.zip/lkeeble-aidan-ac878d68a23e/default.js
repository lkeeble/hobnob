		function sendEmail(user,domain) {
			parent.location.href = "mailto:" + user + "\@" + domain;
		}
		
		x = "";
		function showPic(pic,title,width,height) {
			width += 25;
			height += 75;

			html = "<html>\n<head>\n<title>Camp Photos" + title + "</title>\n<style type=\"text/css\">\n\t<!--\n\tbody, td, div { font-family: \"Tahoma\",sans-serif; font-size: 8pt; }\n\t//-->\n</style>\n</head>\n<body>\n<table align=\"center\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\n\t<tr>\n\t\t<td>\n<div class=\"small\">\n<img src=\""+ pic + "\">\n<div align=\"right\"><strong>" + title + "</strong></div>\n<br>\n<div align=\"center\"><a href=\"javascript:window.close()\">Close Window</a></div>\n</div>\n\t\t</td>\n\t</tr>\n</table></body>\n</html>";
	
			screenHeight = screen.height - 60;
			scrollbars = "no";
			if (screenHeight < height) {
				scrollbars = "yes";
				height = screenHeight;
				width += 15;
			}

			x = window.open('about:blank','_blank','toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars='+scrollbars+',width='+width+',height='+height);
			x.document.write(html);
		}