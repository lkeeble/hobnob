<?php

	include_once("template.php");

	$pageInfo['title_short'] = "Schedule";
	$pageInfo['title_long'] = "Schedule";

	pageHeader( $pageInfo );

?>

<?php schedule() ?>

<?php pageFooter( $pageInfo ); ?>

