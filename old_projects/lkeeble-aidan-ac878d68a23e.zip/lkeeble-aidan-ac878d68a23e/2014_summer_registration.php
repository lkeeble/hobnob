<?php

	include_once("template.php");

	$pageInfo['title_short'] = "Summer 2014 Registration";
	$pageInfo['title_long'] = $pageInfo['title_short'];

	pageHeader( $pageInfo );

?>

<!--
<p>
<h2 style="border: solid 2px red; padding: 5px;">
<blink  class="emphasized">
June 7 2014: Please Note: Summer registration is now closed to new applicants.
<br>
Due to a record enrollment for our 20th year, we are closing our registration and no longer accepting any new camper applications. 
<br>
While we are sad to close enrollment, we want to ensure that we have a quality program for all involved.
</h2>
</blink>
</p>
-->
<p>
Dear Parents:
</p>
<p>
The Tourette Syndrome Camp Organization (TSCO) will host the 21st Annual Tourette Syndrome Camp USA from 
Sunday, June 22, 2014 till Saturday June 28, 2014 at <a href="http://www.ymcacampduncan.org/" target="_new">YMCA Camp Duncan</a> in Ingleside, Illinois.
</p>

<p>
Camp Duncan is situated on a semi-private lake in northeastern Illinois, just south of the Wisconsin border.  
Camp Duncan offers a recreational/residential setting.  
The TS camp program is run concurrently with a traditional YMCA camp week.  
TSCO is <u>not</u> a therapeutic program and there are some limitations in accepting children whose needs are beyond the scope of its design.  
The focus of the camp's staff will be to provide general supervision with as much one-on-one mentoring as well as the situation permits.  
In addition to providing in-services to all Camp Duncan counselors, TSCO supplements the staff by providing volunteer counselors who have TS, or have experience dealing with TS.  
Campers must be able to handle routine daily living skills (i.e., dressing, self-hygiene) and have the ability to function within a group setting.  
While the program is modified to meet the needs of most children whose primary disability is TS and some degree of attention deficit and/or obsessive-compulsive components, 
experience has demonstrated that not every child with TS is capable of participating in the camp program.  
</p>

<p>
This year for our campers who are 16, we are adding a Counselor in Training Program CIT.  
These campers wil be given leadership opportunites that will help with a transition to possible future positions on our staff.
</p>

<p>
The Tourette Syndrome Camping Organization camping fees are based on the price we are given by YMCA Camp Duncan. 
Due to the increase in what we are charged by the YMCA, we have had to raise our base price to $590, however we offer a discount for cash, 
check or money order for $580. As always there are scholarships available.
</p>
<p>
The basic price for camp will be $590, (or $580 for check or money order). 
This amount represents the basic cost for a child to attend camp based on what we are charged by Camp Duncan. 
The all inclusive price for camp is $725. This amount represents the complete cost for a child to attend camp including required 
insurance, medical supplies and cost that we are charged by Camp Duncan for our all volunteer staff. In the past, these costs have been 
covered by donations and fundraising. You may consider paying any amount from $590 ($580) up to $725. Any payment above $580 will be 
considered a donation and assist us with the necessary costs.
We have always asked families who can afford to pay our basic full price based on their financial ability. 
We also offer aid to those families who need assistance based on need. We simply need you to apply. 
Our process is confidential and requests are only known to the President and Camp Director. We are also providing candy that families 
can sell to help pay for your child�s camp fee. Please e-mail or call for details.
While we could apply the funds we have available to reduce our basic price, using our existing model, in our 20 years history, 
we have never had to turn away a child due to need.
</p>

<p>
Please take the time to read the enclosed materials and discuss camp with your child. 
If, after careful consideration, you feel your child is ready for a successful camp experience, please fill out the on line application and mail in a check for $35 or pay a $35 deposit online. 
The deposit is refundable up to, June 5, 2014 minus a $12 service fee.
</p>

<p class="bold">
The Health Form should be turned in no later than June 5, 2014. However any changes in medication or dosage will have to be updated prior to the start of camp.
</p>

<p>
The initial deadline for the Camp Application is June 5, 2014. 
Any application received after June 5, 2014 will require a $50 late fee.  
Please note we may require additional information after reviewing the application including a phone or if possible, an in person interview.
</p>

<p>
We look forward to meeting your child(ren) this summer at Camp Duncan.
</p>			
<p>
    <b>Scott Loeff</b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Monica Newman</b>
<br />
President&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Camp Director
</p>

<h2>Children Traveling to Camp Unescorted to Camp by Plane</h2>
<p>
The Tourette Syndrome Camping Organization (TSCO) can accommodate a limited number of campers who would be flying unaccompanied 
subject to their acceptance to our program and the following conditions:
<ol>
<li>All flights must be in and out of Chicago O'Hare airport.</li>
<li>Flight times must be cleared and approved by TSCO before they are made if pick up and/or drop off is expected. This must be completed no later than 10 days prior to the start of camp.</li>
<li>Any child who is new to our program must first be approved by camp staff before using this procedure.</li>
</ol>
</p>

<h2>Financial Aid</h2>
<p>
TSCO does have aid available. If you are in need of assistance, please fill in the financial aid form below.
Please submit your aid request as soon as possible but not later than May 24, 2014.
</p>
<p>
<div>
   <img style="vertical-align:middle" src="images/bctf.jpg">
   &nbsp;&nbsp;&nbsp;
   Some funding for scholorships is provided by the Brad Cohen Foundation for Tourette Syndrome.
</div>
</p>

<p>
<a target="_new" href="docs/2014_summer_aid.doc">Financial Aid Form (Microsoft Doc)</a>
<br/>
<a target="_new" href="docs/2014_summer_aid.pdf">Financial Aid Form (Adobe PDF)</a>
</p>

<hr style="margin: 20px 0px;">

<p>
<h2>Step-by-Step Guide to Registration</h2>
</p>

<p class="emphasized">
If you need a hard-copy of a form please contact us (info@tourettecamp.com) and we will send one to you.
<br/>
Due to changes in ACA Standards your child must have had an exam by a physican within one year of June 23, 2014.
</p>

<p class="topMargin35px">
<span class="bold">Step 1:</span></b> Print out, complete and turn in part 1 and part 2 of the following Medical History Form by June 5 2014:
</p>


<p>
<a href="docs/2014_summer_medical_history_part1.pdf">Medical History Form (part 1) (Adobe PDF)</a>
<br/><a href="docs/2014_summer_medical_history_part2.pdf">Medical History Form (part 2) (Adobe PDF)</a>
</p>

<p class="topMargin35px">
<span class="bold">Step 2:</span> Complete the online registration:
</p>

<p>
    <a href="2014_summer_register_online.php">Online Application</a>&nbsp;&nbsp;
</p>

<p class="topMargin35px">
<span class="bold">Step 3:</span> Pay your $35 deposit- either pay online using your credit card using the button below or mail in a check.
</p>

<p>
<form name="_xclick" action="https://www.paypal.com/cgi-bin/webscr" method="post">
<input type="hidden" name="cmd" value="_xclick">
<input type="hidden" name="business" value="scott63@prodigy.net">
<input type="hidden" name="item_name" value="Pay Deposit">
<input type="hidden" name="currency_code" value="USD">
<input type="hidden" name="amount" value="35.00">
<input type="submit" border="0" name="submit" alt="Pay $35 deposit" value="Pay $35 deposit via PayPal">
</form>
</p>

<p class="topMargin35px">
<span class="bold">Step 4:</span> If your application is accepted, pay your remaining balance either online (below) or mail in a check.

<p>
<form name="_xclick" action="https://www.paypal.com/cgi-bin/webscr" method="post">
<input type="hidden" name="cmd" value="_xclick">
<input type="hidden" name="business" value="scott63@prodigy.net">
<input type="hidden" name="item_name" value="Summer Camp Remaining Balance">
<input type="hidden" name="currency_code" value="USD">
Balance to Pay:<input type="text" name="amount" value="(type balance here)">
<input type="submit" border="0" name="submit" alt="Pay Remaining Balance" value="Pay Remaining Balance via PayPal">
</form>
</p>

<p class="topMargin35px">
<span class="bold">Step 5:</span> Complete the following risk release and photo release forms:
<br>
(Need forms here)
<!--
<br>
    <a href="2014_online_summer_risk_release.php">Risk Release Form (Online)</a>&nbsp;&nbsp;
</p>

<p>
<a href="2014_online_summer_photo_release.php">Photo Release Form (Online)</a>&nbsp;&nbsp;
-->

<!--
<br/>
	<a href="docs/2014_summer_photo_release.pdf" target="_blank">Photo Release Form (Hard copy, Adobe PDF)</a>
<br/>
	<a href="docs/2014_summer_photo_release.doc" target="_blank">Photo Release Form (Hard copy, Microsoft Word/LibreOffice)</a>
<br/>
-->
</p>

<?php  documentReaderInfo(); ?>

<?php pageFooter( $pageInfo ); ?>
