<?php
	include_once("template.php");
	$pageInfo['title_short'] = "Buy Camp Stuff !";
	$pageInfo['title_long'] = "Buy Camp Stuff !";
	pageHeader( $pageInfo );
?>

<p>
Products that can help raise awareness of Tourette Syndrome: <a href="http://www.cafepress.com/tourettesshop" target="_new">http://www.cafepress.com/touretteshop</a>
</p>
<?php pageFooter( $pageInfo ); ?>