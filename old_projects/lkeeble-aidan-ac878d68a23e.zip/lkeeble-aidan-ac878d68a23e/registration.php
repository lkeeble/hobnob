<?php

	include_once("template.php");

	$pageInfo['title_short'] = "Registration";
	$pageInfo['title_long'] = "Registration";

	pageHeader( $pageInfo );

?>

<!--
<p>The Tourette Syndrome Camp registration forms are available for download in two different file formats, Microsoft Word and Adobe Acrobat (PDF).
If you do not have software to read these file formats, you can get them by clicking on the following links:<br>&nbsp;<br>
<a href="http://www.adobe.com/products/acrobat/readstep.html" target="_blank">Adobe Acrobat PDF Reader</a>
<br>
<a href="http://office.microsoft.com/downloads/2000/wd97vwr32.aspx" target="_blank">Microsoft Word Viewer</a>.
</p>

<p>
To save a copy of a file to your computer, <b>right</b> click on the file and select "Save Link As...". 
<br />Specify or note the location of the file so that you can find it after saving it.
</p>
-->

<h2>Winter 2009 Mini-Camp Registration</h2>

<h3>Secure Online Application</h3>
<table border="0">
    <tr><td>We encourage everyone to use our new secure online registration system and to pay online.</td></tr>
    <tr><td>Please complete and submit <b>BOTH</b> the online application <b>AND</b> the online medical information form.
    </td></tr>
	<tr>
		<td valign="top">
				<a href="register_online_minicamp2009_application.php">Secure Online Application</a>
		</td>
	</tr>
	<tr>
		<td valign="top">
				<a href="register_online_minicamp2009_medical.php">Secure Online Confidential Medical Information</a>
		</td>
	</tr>
	<tr><td height=20 nowrap></td></tr>
</table>

<form action="https://secure.mmoagateway.com/cart/cart.php" method="POST">
<input type="hidden" name="key_id" value="831863" />
<input type="hidden" name="action" value="process_fixed" />
<input type="hidden" name="amount" value="90.00" />
<input type="hidden" name="order_description" value="Winter Mini Camp Payment" />
<input type="hidden" name="language" value="en" />
<input type="hidden" name="url_finish" value="http://www.tourettecamp.com" />
<input type="hidden" name="customer_receipt" value="true" />
<input type="hidden" name="hash" value="action|amount|order_description|f3929efa72d26e60a37d0e55c88caa63" />
<input type="submit" name="submit" value="Pay for Winter Mini Camp Online (Credit Card only)" /> ($90)
</form>

<h3>OR...</h3>
<h3>Paper Application Form</h3>
<table border="0">
    <tr><td>If you prefer not to complete our online application and medical form you may download, complete and mail in our printable application form. 
    To save one of these forms on your computer please <b>right</b>-click and select "save link as...". 
    </td></tr>
	<tr>
		<td valign="top">
				<a href="docs/2009_minicamp_application.pdf">Combined Application and Medical Information Form - Adobe PDF</a>
		</td>
	</tr>
	<tr>
		<td valign="top">
				<a href="docs/2009_minicamp_application.doc">Combined Application and Medical Information Form - Microsoft Word</a>
		</td>
	</tr>
	<tr><td height=20 nowrap></td></tr>
</table>

<?php  documentReaderInfo(); ?>

<? pageFooter( $pageInfo ); ?>

