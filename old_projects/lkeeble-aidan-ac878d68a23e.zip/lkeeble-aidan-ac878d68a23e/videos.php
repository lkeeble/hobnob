<?php

	include_once("template.php");

	$pageInfo['title_short'] = "Videos";
	$pageInfo['title_long'] = "Videos";

	pageHeader( $pageInfo );

?>

<p>
<iframe width="640" height="360" src="https://www.youtube.com/embed/NUxnJzCXdLE?feature=player_detailpage" frameborder="0" allowfullscreen></iframe>
<p>

<p>
<object style="height: 390px; width: 640px"><param name="movie" value="http://www.youtube.com/v/ovx48kFrNYs?version=3"><param name="allowFullScreen" value="true"><param name="allowScriptAccess" value="always">
<embed src="http://www.youtube.com/v/ovx48kFrNYs?version=3" type="application/x-shockwave-flash" allowfullscreen="true" allowScriptAccess="always" width="640" height="360">
</object>
</p>

<p>
<object style="height: 390px; width: 640px"><param name="movie" value="http://www.youtube.com/v/xqKT6UKOmqY?version=3"><param name="allowFullScreen" value="true"><param name="allowScriptAccess" value="always">
<embed src="http://www.youtube.com/v/xqKT6UKOmqY?version=3" type="application/x-shockwave-flash" allowfullscreen="true" allowScriptAccess="always" width="640" height="360"></object>
</p>

<p>
<object style="height: 390px; width: 640px"><param name="movie" value="http://www.youtube.com/v/6j7wOCGsko4?version=3"><param name="allowFullScreen" value="true"><param name="allowScriptAccess" value="always">
<embed src="http://www.youtube.com/v/6j7wOCGsko4?version=3" type="application/x-shockwave-flash" allowfullscreen="true" allowScriptAccess="always" width="640" height="360"></object>
</p>

<p>
<object style="height: 390px; width: 640px"><param name="movie" value="http://www.youtube.com/v/0ph3HNbaKg0?version=3"><param name="allowFullScreen" value="true"><param name="allowScriptAccess" value="always">
<embed src="http://www.youtube.com/v/0ph3HNbaKg0?version=3" type="application/x-shockwave-flash" allowfullscreen="true" allowScriptAccess="always" width="640" height="360"></object>
</p>

<p>
<object style="height: 390px; width: 640px"><param name="movie" value="http://www.youtube.com/v/Xa1D2JiiQsQ?version=3"><param name="allowFullScreen" value="true"><param name="allowScriptAccess" value="always">
<embed src="http://www.youtube.com/v/Xa1D2JiiQsQ?version=3" type="application/x-shockwave-flash" allowfullscreen="true" allowScriptAccess="always" width="640" height="360"></object>
</p>


<!--
<p id="links_articles">
    If you have trouble viewing these videos in your browser you can try to save them to your
    computer and then view them. This can sometimes work better than clicking directly on the link.
</p>
<p>To save the video to your computer, <b>right</b>-click on the link and choose "Save Target As...". <br />
    When the file is done downloading, navigate to the file on your computer and double click on it to play it.
</p>
<p>
    <a href="images/camp/2007_video_party.avi" target="_new">2007 Camp Party Video (5.4 MB)</a> <br />
    <a href="images/camp/2007_video_rehearsal.avi" target="_new">2007 Camp Party Rehearsal (4.5 MB)</a> <br />
    <a href="images/camp/cnn_hero_scott_loeff_320x240_256_15.avi" target="_new">CNN Heroes: Championing Children, Scott Loeff (6.2 MB)</a> <br />
    <a href="images/camp/chicago_works_320x240_256_15.avi" target="_new">Chicago Works May 2008 (16.7 MB)</a> <br />
</p>
-->



<?php pageFooter( $pageInfo ); ?>