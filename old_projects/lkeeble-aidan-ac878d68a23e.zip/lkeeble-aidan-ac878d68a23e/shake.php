<html>
<head>
<script type="text/javascript" src="jquery-1.4.3.min.js"></script>

<script  type="text/javascript">
$(function() {
var interval = 30;
var duration= 1000;
var shake= 3;
var vibrateIndex = 0;

var $selector = $('#shake');

  $('#shake').mouseenter(
    function(){
        vibrateIndex = setInterval(vibrate, interval);
        setTime(stopVibration, 2000);
    });

  $('#shake').mouseleave(
    function() { 
        stopVibration();
    }
    );

  
  var vibrate = function(){
    $selector.stop(true,false)
    .css({position: 'relative',
    left: Math.round(Math.random() * shake) - ((shake + 1) / 2) +'px',
    top: Math.round(Math.random() * shake) - ((shake + 1) / 2) +'px'});
  }
  
  var stopVibration = function() {
    clearInterval(vibrateIndex);
    $selector.stop(true,false)
      .css({position: 'static', left: '0px', top: '0px'});
    };
});
</script>
</head>
<body>
<div id="shake">
TEST TEXT
</div>
</body>
</html>
