<?php

	include_once("template.php");

	$pageInfo['title_short'] = "RSVP for Pabst YMCA March 9 2013";
	$pageInfo['title_long'] = $pageInfo['title_short'];

	pageHeader( $pageInfo );
?>

&nbsp;<br />

<div id="wufoo-w113vgpe0ex74q0">
Fill out my <a href="https://tourettecamp.wufoo.com/forms/w113vgpe0ex74q0">online form</a>.
</div>
<script type="text/javascript">var w113vgpe0ex74q0;(function(d, t) {
var s = d.createElement(t), options = {
'userName':'tourettecamp', 
'formHash':'w113vgpe0ex74q0', 
'autoResize':true,
'height':'812',
'async':true,
'host':'wufoo.com',
'header':'show', 
'ssl':true};
s.src = ('https:' == d.location.protocol ? 'https://' : 'http://') + 'wufoo.com/scripts/embed/form.js';
s.onload = s.onreadystatechange = function() {
var rs = this.readyState; if (rs) if (rs != 'complete') if (rs != 'loaded') return;
try { w113vgpe0ex74q0 = new WufooForm();w113vgpe0ex74q0.initialize(options);w113vgpe0ex74q0.display(); } catch (e) {}};
var scr = d.getElementsByTagName(t)[0], par = scr.parentNode; par.insertBefore(s, scr);
})(document, 'script');</script>

<? pageFooter( $pageInfo ); ?>

