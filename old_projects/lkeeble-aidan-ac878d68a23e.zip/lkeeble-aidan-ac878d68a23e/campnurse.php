<?php

	include_once("template.php");

	$pageInfo['title_short'] = "Camp Nurse Article";
	$pageInfo['title_long'] = "Special Camps for Special Kids";

	pageHeader( $pageInfo );

?>

	<p align="center"><cite>By Scott Williams</cite></p>
	
	<p align="center">
		
		<img src="images/21785-1.jpg" border="1" alt="Mary K. Maloney, RN, BA, a volunteer nurse at Tourette Syndrome Camp USA in Ingleside, Ill., says the kids who attend the camp can be themselves and bond with other kids with Tourette Syndrome." />
		<br />
		<small><em> Mary K. Maloney, RN, BA, a volunteer nurse at Tourette Syndrome Camp USA in Ingleside, Ill., says the kids who attend the camp can be themselves and bond with other kids with Tourette Syndrome.</em></small>
	</p>

	<p><strong><em>Kids and teens with similar medical needs learn together and play together under the summer sun</em></strong></p>

	<p>Summer camp is a right of passage for many children. It's often the first instance when a child spends a significant amount of time away from his or her family and builds memories of living in a cabin, swimming, and telling ghost stories around the campfire that last a lifetime.</p>
	
	<p>While every summer camp is special to someone, camps that provide a summer escape for children with physical and mental illnesses are even more special. For many children, attending camp is their first opportunity to meet other children who share their challenges. In some camps, these children also learn more about their diseases and ways to better manage them. It's often a life-changing experience that transforms them and their parents.</p>
	
	<p>Every camp has at least one nurse on staff; some of them earn a paycheck, while many others volunteer their time. These nurses bandage scraped knees and treat upset stomachs and headaches. But they also help children with health-related problems learn, grow, and, at the same time, have fun, because, after all, they are at summer camp.</p>

	<h2>Tourette Syndrome Camp USA</h2>
	
	<p>Nurses at Tourette Syndrome Camp USA in Ingleside, Ill., help children ages 8 to 17 with this misunderstood disorder escape for a little while from what are often difficult lives, says Mary K. Maloney, RN, BA, a volunteer nurse at the camp. Their lives aren't difficult because of Tourette Syndrome, she says, as much as because of the way society treats them. Other children tease or bully them, and adults don't know how to handle them.</p>
	
	<p>"When they get up to the camp they realize that they're just kids and that we see them for who they are," says Maloney, whose regular job is with a medical device company. "[Tourette Syndrome] is so rare that generally when children come to our camp, they've never met another child who has it."</p>

	<p>Children who attend camp must have a primary diagnosis of Tourette Syndrome, but they often have coexisting conditions such as attention deficit hyperactivity disorder, obsessive compulsive disorder, bipolar disorder, or Asperger's Disorder. They do not have to be recommended by a doctor. This year's camp will be held from June 25 through July 1. The cost is $450 per camper or $500 for those who register after June 7. The total cost per camper is around $600 with the balance paid for through fund-raisers. There is no waiting list to get into the camp.</p>
	
	<p>Maloney, whose 15-year-old son has been diagnosed with Tourette Syndrome, says campers enjoy boating activities on the lake, campfires, flag ceremonies, and other typical camp activities.</p>
	
	<p>"The nurse job is probably the most demanding because you are literally on call for 24 hours and you do all the medications," she says. "You start your medications at about seven in the morning and give out night medications at about eight at night."</p>
	
	<p>Children enjoy the camp experience so much, Maloney says, that even children who have never spent a single night away from their families have a hard time saying goodbye.</p>
	
	<p>"The last day of camp you see kids hugging each other and getting teary," she says. "It's a transforming experience."</p>
	
	<p>Parents find the experience transforming as well.</p>

	<p>"I've had parents actually get to camp and just say, 'If you don't mind, I just want to watch for a while because I've never seen my son so happy. I've never seen my son socialize like this,'" continues Maloney.</p>
	
	<p>Nurses and others interested in volunteering should contact The Tourette Syndrome Camp Organization at (773) 465-7536.</p>
	
	<h2>Camp Warren Jyrch</h2>
	
	<p>Kids at Camp Warren Jyrch, named for the first person with hemophilia to have open-heart surgery, learn important survival skills during their week at the camp in Leaf River, Ill.</p>
	
	<p>But they don't learn how to build a fire or live off the land. Instead, they learn how to self-infuse blood-clotting medication and manage their own bleeds, says Kathe Gusler, RN, a volunteer nurse at the Hemophilia Foundation of Illinois' summer camp for the past seven years.</p>
	
	<p>At camp, children with hemophilia between the ages of 7 and 17 learn to mix a powdered form of a synthetic blood product with sterile water, draw it up in a syringe, and inject it into a vein using a butterfly needle. The synthetic blood product helps their blood to clot properly and keeps them from bleeding into their joints, a common problem among people with hemophilia.</p>
	
	<p>"We encourage that and we make a big deal out of that, and they get a certificate and trophies on awards night," says Gusler, a hospice nurse whose 20-year-old son has hemophilia. "They are so proud of themselves when they do it."</p>
	
	<p>Kids at Camp Warren Jyrch, which will be held this year from July 23-29, canoe, swim, climb rocks, play volleyball, enjoy campfires, and even participate in archery. Parents are asked to consider paying $250 toward the $1,000-per-child camp costs and around one-third of families contribute something, says Bob Robinson, the camp's executive director. Campers are accompanied by one of three volunteer nurses in case of an accident because problems are easier to manage immediately after they occur.</p>
	
	<p>"One of the things I can honestly say camp did for (my son) is it made him more independent in his care," says Gusler, whose son attended the camp before she became a nurse. "It was a good experience for him to know that he wasn't out there alone."</p>
	
	<p>"As a parent of a boy with hemophilia, it was the best week of my life," continues Gusler. "I knew they had people who could take care of him. It was the one week I didn't worry. Camp is fabulous; every kid should come."</p>
	
	<p>To learn how to volunteer, contact the Hemophilia Foundation of Illinois at (312) 427-1495.</p>

	<div class="box">

			<strong>
				Information on other Illinois camps is just a click away
		    </strong>
			<hr/>
			To search for a camp in Illinois visit <a href="http://www.mysummercamps.com">www.mysummercamps.com</a> and use the "Find A Camp" feature to search for camps - health related and otherwise - based on activity, camp type, city, state, and gender. A recent search uncovered 354 camps in Illinois alone.
	</div>

	<p>
		<small><em>
			Source: <a href="http://community.nursingspectrum.com/MagazineArticles/article.cfm?AID=21785" target="_blank">Nursing Spectrum - Career Fitness Online</a>
		</em></small>
	</p>

<? pageFooter( $pageInfo ); ?>
