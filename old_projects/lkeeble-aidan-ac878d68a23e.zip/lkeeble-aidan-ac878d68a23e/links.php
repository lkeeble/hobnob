<?php

	include_once("template.php");

	$pageInfo['title_short'] = "Links";
	$pageInfo['title_long'] = "Links";

	pageHeader($pageInfo);

?>

<p id="link_list">
	<a href="http://www.tsa-usa.org" target="_blank" title="National Tourette Association Web Site - http://www.tsa-usa.org">National Tourette Syndrome Association Website</a>
	<a href="http://www.tsa-illinois.org" target="_blank">Tourette Syndrome Association of Illinois, Inc.</a>
	<a href="http://www.ts-mtic.org" target="_blank">Tourette Syndrome Multicultural Outreach Association, Inc.</a>
	<a href="http://www.irn-ts.org/" target="_blank">Illinois Resource Network for Tourette Syndrome and Related Disorders (IRN-TS)</a>
	<!-- <a href="http://www.cafepress.com/tourettesshop" target="_blank"">Products (clothing, fridge magnets, etc.) that can help raise awareness of Tourette Syndrome</a> -->
</p>	

<?php pageFooter( $pageInfo ); ?>