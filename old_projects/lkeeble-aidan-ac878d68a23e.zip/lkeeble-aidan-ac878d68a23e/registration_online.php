<?php

	include_once("template.php");

	$pageInfo['title_short'] = "Register Onlne";
	$pageInfo['title_long'] = "Register Online";

	pageHeader( $pageInfo );

?>

<h2>Winter Mini-Camp Registration</h2>

<iframe height="2941" allowTransparency="true" 
frameborder="0" scrolling="no" 
style="width:100%;border:none;" 
src="http://tourettecamp.wufoo.com/embed/camper-application/">
<a href="http://tourettecamp.wufoo.com/forms/camper-application/" title="html form">
Fill out my Wufoo form!
</a></iframe>

  
<? pageFooter( $pageInfo ); ?>

