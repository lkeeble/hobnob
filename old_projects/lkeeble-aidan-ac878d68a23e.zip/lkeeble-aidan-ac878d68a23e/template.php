<?php
error_reporting(0);

function pageHeader( $pageInfo = Array()) {
$externalCssJsVersion = "2";
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="en-US" xml:lang="en-US" xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" type="text/css" href="reset.css">
<link rel="stylesheet" type="text/css" href="tscamp.css?version=<?php echo $externalCssJsVersion ?>" />
<title>Tourette Syndrome Camp Organization - <?php echo $pageInfo['title_short']?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />

<script type="text/javascript" src="jquery-1.4.3.min.js"></script>
<script type="text/javascript" src="tscamp.js?version=<?php echo $externalCssJsVersion ?>"></script>

</head>
	
<body>
<div id="pageContent">
<div id="tscamplogo">
<img src="images/4colorm.jpg" alt="Accredited by the American Camp Association" />
<a href="index.php" alt="Illinois Tourette Syndrome Camp Organization">
<img src="images/layout/titleImage_cropped.png" alt="Illinois Tourette Syndrome Camp Organization" />
</a>
</div>

<table style="margin-top: 10px; margin-bottom: 20px;">
<tr>
<td width="500px">
	<div id="address">
		<div>Chicago, Illinois 60640</div>
		<div>Tel: &nbsp;(773) 465-7536</div>
	</div>
	<font size="-1"><i>The Tourette Syndrome Camp Organization is a 501 (c) (3) non-profit organization.</i></font>
</td>
<td valign="middle" align="center">
	<br/>
    <a href="http://www.facebook.com/groups/156667161030448/" target="_new"><img src="images/findUsOnFacebook.jpg" /></a>
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</td>
<td>
<span id="contact">
    <a href="mailto:info@tourettecamp.com?subject=(email sent from tourette camp web site)&cc=mon1112@sbcglobal.net">Contact Us</a>
	<br/>&nbsp;<br/>
	<font size="-1">Email: info@tourettecamp.com</font>
</span>
</td>
</tr>
</table>

<div class="menubar rounded border">
	<ul>
		<div border=1px solid blue;>
			<li><a href="index.php" title="Home">Home</a></li>
			<li><a href="schedule.php" title="Schedule">Schedule</a></li>
			<!-- <li><a href="staff.php" title="Staff">Staff (Apply!)</a></li> -->
			<li><a href="registration_dc_2014.php" title="Register">Register (DC)</a></li>
			<li><a href="photos.php" title="View Camp Photos">Photos</a></li>
			<li><a href="videos.php" title="View Camp Videos">Videos</a></li>
			<li><a href="articles.php" title="Articles">Articles</a></li>
			<!-- <li><a href="buystuff.php" title="Buy Camp Stuff">Buy Camp Stuff</a></li> -->
			<li><a href="donations.php" title="Donations">Donate</a></li>
			<li><a href="links.php" title="Links">Links</a></li>
		<!-- 
		<a href="registration_summer2014.php" title="Register">Register (Summer)</a>
		<a href="2012_register_shamrock_smokies.php" title="Register">Register (Shamrocks)</a>
		<a href="staff.php" title="Staff">Staff (Volunteer)</a> 
		-->	
		</div>
<!--
		<div style="margin-top: 35px; text-align: center;">
			<li><a href="2013_summer_registration.php" title="Register for Summer Camp 2013">Register for Summer Camp 2013</a></li>
			<li><a href="registration_bowling_2014.php" title="Bowling RSVP">Bowling RSVP</a></li>
		</div>
-->			
	</ul>
</div>

<!--
<p>
<b><i>Countdown to Tourette Syndrome Camp USA:</i>&nbsp;<font color="fuchsia"><span id="countdown"></span></font></b>&nbsp;&nbsp;&nbsp;&nbsp;
<img src="images/dancingbanana.gif" />
</p>
-->

<?php
if (!empty($pageInfo['title_long'])) 
{
?>
    <br />&nbsp;<br />
    <h1 align="left"><?php echo $pageInfo['title_long'] ?></h1>
    <hr />
<?php
}
?>

<?php
}

function pageFooter( $pageInfo = Array() ) 
{
?>
<div id="copyright">
<table>
	<tr>
		<td nowrap>
			<a href="http://wufoo.com" target="_new">Online Forms by Wufoo</a>
		</td>
		<td width="90%">
			Copyright &copy;2002-2013 Tourette Syndrome Camp Organization.
			All Rights Reserved.
		</td>
	</tr>
</table>
</div>
</body>
</div> <!-- end pageContent div -->
</html>
<?php
}

function schedule()
{
?>
<p style="clear:both;">
<h2>2014 schedule</h2>
</p>


<!-- 
<div class="boxItem">
	<h3>Coming soon!</h3>
</div>
-->
<div class="boxItem">
<p>
Bowling  Brunswick Zone Deerfield<br>
Saturday February 22, 2014 <br>
10 South Waukegan Road<br>
Deerfield, IL 60015<br>
1:30-3:30PM. <br>
Minimum suggested donation $8 per person up to $13. 
</p>
<p>
<a href="registration_bowling_2014.php">RSVP for the Bowling event</a>
</p>
</div>

<div class="boxItem">
<p>
Family Day at YMCA at Pabst Farm<br>
Saturday, March 9, 2014 from 10am to 3:00pm <br>
1750 E. Valley Road<br>
Oconomowoc, WI  53066<br>
Minimum suggested donation is $10 per child up to $20 and $5 for lunch for each child or adult
</p>
<p>
<a href="registration_ymca_2014.php">RSVP for the YMCA event</a>
</p>
</div>

<div class="boxItem">
<p>
Children's Program at National TSA Conference in Washington DC. <br>
<a href="registration_dc_2014.php">Click to register</a><br>
Friday  March 21, 2014 from 8:30AM to 6:00PM and Saturday March  22, 2014 from 8:45AM till 5:00PM<br>
Cost is a minimum of $275 up to $300 to cover full costs
</p>
</div>

<div class="boxItem">
<p>
Our Flagship Program Tourette Syndrome Camp USA summer camp<br> 
Sunday, June 22, 2014 till Saturday June 28, 2014 at YMCA Camp Duncan. 
<br>Cost will be $590 per child ($580 for check/Money order).
<br>Registration will be available after 1/1/14.
</p>
</div>

<!--
<div class="boxItem">
	<h3>Tourette Syndrome Camp USA Summer 2013</h3>
	<p>
	Tourette Syndrome Camp USA will run from Sunday 6/23/13 till Saturday 6/29/13.
	</p>
	<p>
	Cost range is the minimum fee of $575 ($565 for check or money orders) up to $710 to cover our full cost. 
	</p>
	<p>
		<a target="_new" href="2013_summer_registration.php" title="Register for Summer Camp 2013">Register for Summer Camp 2013</a>
	</p>
	<p>
	Check summer camp 2012 photos on our 
	<a target="facebook" href="http://www.facebook.com/groups/156667161030448/">facebook page</a>.
	</p>
</div>

<div class="boxItem">
	<h3>Sunday March 24, 2013  YMCA at Pabst Farms (10AM - 3PM)</h3>
	<p>
	<a href="http://www.ymcaatpabstfarms.org/">YMCA at Pabst Farms</a>
	</p>
	<p>
	1750 East Valley Road
    Oconomowoc, WI 53066
	</p>
	<p>
	Activities will include swimming, a climbing wall and more. Some of our camp staff will be on hand for this fun day.<br/>
	We are asking for a minimum donation of $10 per child up to $20 cover our costs and $5 for each adult for lunch.<br/>
	Payment can be cash or check on the day of the event, or 
	online via PayPal using the following payment button:
	</p>
	<div style="margin-top: 10px;">
		<form name="_xclick" action="https://www.paypal.com/cgi-bin/webscr" method="post">
		<input type="hidden" name="cmd" value="_xclick">
		<input type="hidden" name="business" value="scott63@prodigy.net">
		<input type="hidden" name="item_name" value="TSCO YMCA Payment">
		<input type="hidden" name="currency_code" value="USD">
		<input type="hidden" name="amount" value="25.00">
		<input type="submit" value="Pay for Pabst YMCA via PayPal"
		border="0" 
		name="submit" 
		alt="Pay for Pabst YMCA via PayPal">
		</form>
	</div>
	
	<p class="emphasized">
		Please RSVP for the event using our <a href="registration_ymca_2013.php">online RSVP form</a>. 
	</p>
</div>
-->

<h2>More Information</h2> 
<p>If you would like more information or desire to be put on our mailing list, 
please <a href="javascript:sendEmail('info','tourettecamp.com')">e-mail</a> or call us at (773) 465-7536.
</p>
<div style="margin: 10px;">&nbsp;</div>
<?php
}

function documentReaderInfo()
{
?>
<div id="doc_instructions" style="margin-top: 20px;">
<hr />
<p>
<b>Document download/printing instructions:</b>
</p>
<p>To save a form on your computer please <span class="bold">right</span>-click and select "save link as...".<br/>
You may need one or more of the following free document readers:<br />
</p>

<p>
<a href="http://www.libreoffice.org/" target="_blank">LibreOffice Free Office Suite (includes MS Word reader)</a> <br />
<a href="http://www.foxitsoftware.com/downloads/" target="_blank">Foxit PDF Reader</a> <br />
<a href="http://www.adobe.com/products/acrobat/readstep.html" target="_blank">Adobe Acrobat PDF Reader</a> <br />
</p>
</div>
<?php
}
?>