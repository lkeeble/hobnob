<?php
include_once("template.php");
$pageInfo['title_short'] = "Summer 2013 Risk Release Form";
$pageInfo['title_long'] = "Summer 2013 Risk Release Form";
pageHeader($pageInfo );
?>

&nbsp;<br />

<div id="wufoo-wpi5tlf0kcl24j">
Fill out my <a href="https://tourettecamp.wufoo.com/forms/wpi5tlf0kcl24j">online form</a>.
</div>
<script type="text/javascript">var wpi5tlf0kcl24j;(function(d, t) {
var s = d.createElement(t), options = {
'userName':'tourettecamp', 
'formHash':'wpi5tlf0kcl24j', 
'autoResize':true,
'height':'2899',
'async':true,
'host':'wufoo.com',
'header':'show', 
'ssl':true};
s.src = ('https:' == d.location.protocol ? 'https://' : 'http://') + 'wufoo.com/scripts/embed/form.js';
s.onload = s.onreadystatechange = function() {
var rs = this.readyState; if (rs) if (rs != 'complete') if (rs != 'loaded') return;
try { wpi5tlf0kcl24j = new WufooForm();wpi5tlf0kcl24j.initialize(options);wpi5tlf0kcl24j.display(); } catch (e) {}};
var scr = d.getElementsByTagName(t)[0], par = scr.parentNode; par.insertBefore(s, scr);
})(document, 'script');</script>


<? pageFooter( $pageInfo ); ?>

