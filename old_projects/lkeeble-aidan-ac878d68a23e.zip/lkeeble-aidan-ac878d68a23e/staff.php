<?php

	include_once("template.php");

	$pageInfo['title_short'] = "Staff";
	$pageInfo['title_long'] = "Staff";

	pageHeader( $pageInfo );

?>

<h2>
<blink>
<font color="red">As of April 10th 2013 we are no longer considering <u>new staff</u> applications only <u>returning staff</u> applications. <br></font>
</blink>
</h2>

<p>
If you are a <span class="bold">returning</span> staff member you can go directly to the <a href="2013_summer_staff_application.php">Online Staff Application</a>.
</p>

<p>
The Tourette Syndrome Camping Organization is seeking volunteers to staff our 2013 summer camp program, Tourette Syndrome Camp USA. 
</p>
<p>
This year's program runs from Sunday, June 23 until Saturday, June 29, 2013 at YMCA Camp Duncan Near Fox Lake, 
Illinois (35 miles North of Chicago). All staff will be required to attend a training session on Saturday, June 22, 2013 at Camp Duncan. 
</p>
<p>
If you are interested in applying, please review the job description for available positions and fill in the online application forms. 
You should also review our staff manual which provides details, expectations and responsibilities of our staff. 
<p>
<a target="_other" href="docs/Staff Manual Draft4.pdf">Staff Manual (Adobe PDF)</a><br>
<a target="_other2" href="docs/Staff Manual Draft4.doc">Staff Manual (Microsoft Word)</a><br>
</p>
<p> 
Upon receipt of your application a follow up interview by phone or in person will be required for new staff. 
Interviews will be done in Late March or Early April. Reference and background checks will also be conducted. 
If you were on Staff for our 2012 Summer Camp you only need to fill out Pages 1 and 4 on the application. 
</p>
<p>
Staff selection will be done by our camp committee and is also based on the number of campers that will be attending this year's program. 
We do give preference to returning staff. 
</p>
<p>
Please contact us if you have any questions. 
</p>

<p>
Scott Loeff&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Monica Newman
<br />
President&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Camp Director
</p>

<br>
<hr>
<br>

<h3>Job Descriptions</h3>

<!--
<p>
<b>Camp Director</b> 
<p>
This person is in charge of the camping program. 
She/He is responsible for the smooth operation and coordination of all activities and programs and 
administration of all camp programs including Winter Mini Camp, Washington DC Children's Program and any 
other programs. This includes supervision of the Program Director(s), assisting the Program Director as needed, 
counseling of campers if necessary, and taking charge in case of emergency. 
She/He is responsible to the Board of Directors.
<p>
<b>Program Director</b>
<p>
This person is in charge of the Tourette Syndrome Summer Camp USA or other programs.  
She/He is responsible for smooth operation and coordination of all activities and programs and 
administration of the Tourette Syndrome Summer Camp USA. This includes staff supervision, counseling of 
campers if necessary, and taking charge in case of emergency. She/He is responsible to the Camp Director.
-->
<p class="bold">
Assistant Camp Director 
</p>

<p>
This is the counselor who is to assume duties of Camp Director if she or he is away from the campsite 
for some reason. She/He is responsible to the Camp Director. The Camp Director may assign additional 
duties to the Assistant Camp Director as needed during camp. The Camp Director will appoint any Assistant Camp Directors. 
</p>

<p class="bold">
Senior Counselor
</p>

<p>
The counselor is directly responsible for continual supervision of campers. 
The counselor is to facilitate the group process, while ensuring camper safety and 
creating a positive camper experience. Counselors need to be willing and able to participate 
with their campers in the majority of camp activities. Camp counselors need to demonstrate sensitivity 
to the needs of campers, interact appropriately with campers in a variety of situations and use 
positive behavior management techniques. Counselors are expected to model and demonstrate mature, appropriate, 
adult behavior. Enthusiasm, a sense of humor, patience and self-control are the model behaviors 
for our camp counselors. Counselors must have the ability to communicate/coordinate tasks and responsibilities 
with co-counselors or seek assistance from Camp Director.  Must be at least 19 years old by the time camp 
begins.
</p>
<p>
Other responsibilities include participation in pre-camp training the day before camp begins. 
Counselors must be able to attend post-camp evaluation meeting and complete camp and camper evaluation 
forms prior to leaving camp. 
</p>

<p class="bold">
Junior Counselor
</p>

<p>
The Junior Counselor role is to model positive behavior and interactions for campers. 
They are to assist the counselors with tasks, but are NOT directly responsible for campers. 
Neither is a Junior Counselor expected to be exclusively responsible for errand-running, menial tasks 
or "go-fer" work. Junior Counselors are expected to show mature, appropriate behavior.  
The oldest cabins may have a Junior Counselor if that person is 2 years older than the campers. 
Junior Counselors must be at least 17 years old by the time camp begins.
</p>

<p class="bold">
Camp Health Manager
</p>

<p>
He/She is responsible for the health and welfare of the campers and is in charge of the first aid building. 
His/her duties include checking campers into and out of camp, treating sick or injured persons, 
keeping a medical log of all treatments and dispensing all internal medication. The Camp Health Manager 
is expected to participate in staff meetings during the camp session and work closely with the 
Camp Director in contacting parents, if necessary, regarding camper accidents / injuries.
</p>

<p>
The Camp Health Manager will be responsible for taking possession of medication and, when possible, 
talking to parents about camper health concerns during registration. After the health screenings at camp, 
the Camp Health Manager will inform counselors which children in their cabins need medication on a regular basis. 
Upon completion of the camp session, the Camp Health Manager will return medicine to parents as they pick 
up their child.	
</p>

<p class="bold">
Director of Camper Success
</p>

<p>
He/She is responsible for training all staff on the disorders and mental health concerns. 
He/She is responsible for the mental health and welfare of the campers. His/her duties include 
checking on campers who have been identified as having severe symptoms, anxiety and homesickness. 
He/She will also be responsible for monitoring campers� behavior concerns, intervening when necessary. 
The Director of Camper Success is expected to participate in staff meetings during the camp session 
and work closely with the Camp Director in contacting parents, if necessary, regarding camper 
behaviors and concerns. He/She will be available at all times for intervention when requested 
by camp staff. He/She will provide support for cabin counselors, offering suggestions to help cabin 
counselors with specific concerns. He/she is responsible to the Camp Director.
</p>

<p>
<hr>
<p>
<h3>Application Form</h3>
<p>
<a href="2013_summer_staff_application.php">Online Staff Application</a>
</p>
<!--
<br/>
<a href="docs/2012_staff_application_form.doc">Staff Application Form</a> (Microsoft Word)
<br/>
<a href="docs/2012_staff_application_form.pdf">Staff Application Form</a> (PDF)

<br/>
-->

<p>
In addition to the application form above, staff members should also complete and the following liability waiver and the photo release forms:
</p>

<p>
    <a href="2013_online_summer_risk_release.php">Online Risk Release Form</a>
</p>
<!--
<br/>
	<a href="docs/2012_summer_risk_release.pdf" target="_blank">Risk Release Form</a> (Adobe PDF)
<br/>
	<a href="docs/2012_summer_risk_release.doc" target="_blank">Risk Release Form</a> (Microsoft Word/LibreOffice)
<br/>
-->

<p>
<a href="2013_online_summer_photo_release.php">Online Photo Release Form</a>
<!--
<br />
	<a href="docs/2012_summer_photo_release.pdf" target="_blank">Photo Release Form</a> (Adobe PDF)
<br>
	<a href="docs/2012_summer_photo_release.doc" target="_blank">Photo Release Form</a> (Microsoft Word/LibreOffice)
-->	
</p>


<!--
<?php  documentReaderInfo(); ?>
-->

<?php pageFooter( $pageInfo ); ?>

