<?php

	include_once("template.php");

	$pageInfo['title_short'] = "Donations";
	$pageInfo['title_long'] = "Donations";

	pageHeader( $pageInfo );

?>

<p>
The Tourette Syndrome Camp Organization is a 501 (c) (3) non-profit organization. <br />
We can always use cash donations or in-kind donations for our camp programs.
All donations are tax deductible. 
</p>

<p>Click on the following button to donate using <b>PayPal</b>: 
<form name="_xclick" action="https://www.paypal.com/cgi-bin/webscr" method="post">
<input type="hidden" name="cmd" value="_xclick">
<input type="hidden" name="business" value="scott63@prodigy.net">
<input type="hidden" name="item_name" value="TSCO Donation">
<input type="hidden" name="currency_code" value="USD">
<!-- <input type="hidden" name="amount" value="25.00"> -->
<input type="image" src="images/btn_donate_LG.gif" 
border="0" 
name="submit" 
alt="Donate to the Tourette Syndrome Camp Organization using PayPal">
</form>
</p>

<p>
Or, you can write a check made payable to TSCO and send it to:
</p>

<p>
TSCO c/o Scott Loeff<br>
4416 N. Greenview Ave. Unit E<br>
Chicago, IL 60640<br>
</p>

<!--
<p>If you wish to donate by credit card, please e-mail scott63@prodigy.net so we can 
send you a paypal link.
</p>
-->
<p>We can always use the follow items for our camp programs:</p>

<ul>
<li>Bottled water</li>
<li>Sports drinks</li>
<li>First aid supplies</li>
<li>Fruit</li>
<li>Snacks</li>
<li>Paper cups</li>
<li>Plastic Silverware</li>
<li>T-shirts</li>
<li>Paper</li>
<li>Pens</li>
<li>Pencils</li>
<li>Markers</li>
<li>Sleeping bags</li>
</ul>

<p>
In addition:
</p>

<ul>
<li>Printing</li>
<li>Postage</li>
</ul>

<?php pageFooter( $pageInfo ); ?>