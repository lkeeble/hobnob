<?php

	include_once("template.php");

	$pageInfo['title_short'] = "Registration";
	$pageInfo['title_long'] = "Registration";

	pageHeader( $pageInfo );

?>


<h2>Registration for Washington DC Program March 2014</h2>

<p>
Children's Program at National TSA Conference in Washington DC.<br>
Friday March 21, 2014 from 8:30AM to 6:00PM and Saturday March 22, 2014 from 8:45AM till 5:00PM.<br>
The cost is $275 per child. If you'd like to help us cover the cost of the full program for your child then consider up to $300 per child.
</p>

<p>
On Friday, March 21, 2014 we will have programming at and around the Crystal Gateway Marriot Hotel. 
This will include outside activities and a number of speakers. On Saturday March 22, 2014 we will have a bus tour of Washington DC. 
On both days we will have lunch at the hotel.
</p>
<p>
The program will be staffed by members of our volunteer camp staff which consists mainly of high school, college students and young adults who 
have Tourette Syndrome or who have worked with children with TS and its associated disorders. 
Please note that we cannot handle or administer any medications. However, we will be at the Hotel both days for lunch in case your 
child has any lunch time medications.
</p>

<p>
If you are interested in having your child attend our program, please fill out the online application or download the application and send via postal mail.</p>
</p>

<h2>Financial Aid</h2>
<p>
<b>Financial Aid Application - Complete and Mail In If Needed:</b>

<p>
	<a href="docs/2014_dc_aid3.pdf" target="_blank">Washington DC Financial Aid Application (Adobe PDF)</a>
<br>
	<a href="docs/2014_dc_aid3.doc" target="_blank">Washington DC Financial Aid Application (Open Office/Microsoft Word)</a>
<br>
Mail to: Tourette Syndrome Camp Organization, 4416 N.Greenview Ave. Unit E, Chicago, IL 60640.
</p>

<p class="topMargin35px">
<b>Step 1.</b> Either complete the online registration (strongly preferred) OR print out and turn in the single registration form below. 

<p>Online Application: <a href="register_online_dc_2014.php">DC March 2014 Online Application</a>&nbsp;&nbsp;
<p>
<b>OR</b>
</p>

<p>
Application document, print one and mail in to:
<br> Tourette Syndrome Camp Organization, 4416 N.Greenview Ave. Unit E, Chicago, IL 60640.
<!-- <font color="red"> NOTE 11/20/2013: We are currently updating our application form. Please check back soon to download it.</font> -->
<br>
	<a href="docs/2014_dc_application-2.pdf" target="_blank">Washington DC March 2014 Application (Adobe PDF)</a>
<br>
	<a href="docs/2014_dc_application-2.doc" target="_blank">Washington DC March 2014 Application (Open Office/Microsoft Word)</a>
<br>
<p>

<p class="topMargin35px">
<b>Step 2.</b> Print out and turn in one of the release forms below: 
<br>
	<a href="docs/2014_dc_release.pdf" target="_blank">Washington DC March 2014 Release Form (Adobe PDF)</a>
<br>
	<a href="docs/2014_dc_release.doc" target="_blank">Washington DC March 2014 Release Form (Open Office/Microsoft Word)</a>
<br>
</p>

<p class="topMargin35px">
<p><b>Step 3.</b>Click on the following button to pay your $25 deposit via PayPal (preferred), or mail in a check for $25 made payable to "Tourette Syndrome Camping Organization" to 4416 N.Greenview Ave. Unit E, Chicago, IL 60640.
<form name="_xclick" action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_paypal">
<input type="hidden" name="cmd" value="_xclick">
<input type="hidden" name="business" value="scott63@prodigy.net">
<input type="hidden" name="item_name" value="Deposit for TSCO March 2014 DC Trip">
<input type="hidden" name="currency_code" value="USD">
<input type="hidden" name="amount" value="25" size="6">
<input type="submit" value="Pay Deposit of $25 with PayPal">
</form>
</p>


<p class="topMargin35px">
<b>Step 4.</b>Once accepted into the DC Program, click on the following button to pay your balance via PayPal (preferred), or mail in a check made payable to "Tourette Syndrome Camping Organization" to 4416 N.Greenview Ave. Unit E, Chicago, IL 60640.
<form name="_xclick" action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_paypal">
<input type="hidden" name="cmd" value="_xclick">
<input type="hidden" name="business" value="scott63@prodigy.net">
<input type="hidden" name="item_name" value="Balance for TSCO March 2014 DC Trip">
<input type="hidden" name="currency_code" value="USD">
Balance to Pay: $<input type="text" name="amount" value="250.00" size="6">
<input type="submit" value="Pay Balance with PayPal">
</form>
</p>

<p class="topMargin35px">
<b>Step 5.</b> (optional) Print out and turn in one of the photo release forms below: 
<br>
	<a href="docs/photo_release.pdf" target="_blank">Photo Release Form (Adobe PDF)</a>
<br>
	<a href="docs/photo_release.doc" target="_blank">Photo Release Form (Open Office/Microsoft Word)</a>
<br>
</p>

<p class="topMargin35px">
<b>Optional arbitrary payment via PayPal</b><br/>
If needed, you can use the following button to pay any amount you need to pay.<br/>
Just enter the amount yourself in the box. <br/>
<form name="_xclick" action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_paypal">
<input type="hidden" name="cmd" value="_xclick">
<input type="hidden" name="business" value="scott63@prodigy.net">
<input type="hidden" name="item_name" value="Payment for TSCO March 2014 DC Trip">
<input type="hidden" name="currency_code" value="USD">
Amount to Pay: $<input type="text" name="amount" size="6">
<input type="submit" value="Pay with PayPal">
</form>
</p>



<?php  documentReaderInfo(); ?>

<?php pageFooter( $pageInfo ); ?>

