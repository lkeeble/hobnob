<?php

	include_once("template.php");

	$pageInfo['title_short'] = "My Week At Tourette Camp";
	$pageInfo['title_long'] = "My Week At Tourette Camp";

	pageHeader( $pageInfo );

?>

<cite>By Jaime Biava </cite>
<p>"My tics are better than your tics." That was, for one week in time but forever in memory, our motto. 
I had never really been to summer camp before. Well, there was that one experience as a resident camper
at your typical "scouts" summer camp that I've just about erased from my memory. Thankfully. A good time
was not had by all. But that was during one of the dark times in my life when the words "Tourette Syndrome"
and "OCD" were not fully understood. I was just "different," in so many ways.
</p>

<p>
Although I still had a bad taste in my mouth about the possibilities of summer camp, I stumbled upon a
website advertising a summer camp in Illinois and became intrigued. 
When I thought about volunteering as a counselor, a familiar cringe grabbed my stomach. 
Could I really survive another round of camp? I was skeptical - it looked too good to be true! "The goal of
this camp," reads the website, "is to allow children with TS an opportunity to meet other children, share
similar experiences and coping mechanisms in a fun, safe and positive environment." 
I just had to go. 
</p>

<p>
So it was with a sleeping bag, pillow, backpack, and much excitement and anxiety that I made my way to Chicago. 
When I got there and met with the director and the rest of the camp staff, I knew this was going to be
very different from my previous experience. 
There were more staff than there were registered campers (which proved necessary for everyone's sake!) and
all but a couple of us had Tourette Syndrome. 
The few that did not were intimately connected with the syndrome through friends or family members. 
It was better than Disneyland... it was Tourette Camp! 
</p>

<p>
Everyone was ticing and no one cared. It took my group of 10 to 12 year old boys some time to comprehend that
all of the kids and most of the adults around them had Tourette Syndrome just like them. During breakfast a few
days into camp, one of the campers asked quite skeptically, "Do all the people here have Tourette?" Another
camper turned to him and gave him a sort of "well, duh" answer, and then shot a quick glance at one of the
counselors for reassurance that it was indeed true. Another time one of the boys was sitting with me to calm
down after a bit of rage. We were chatting, talking about how he felt, when I told him that I thought I might
be able to relate. I described how I used to feel. How I would lose control and how it can be scary and really
hard sometimes. He turned to me and asked if I really used to do that. I got to tell him "yes" and watch his
face lighted in camaraderie. I was surprised at how I felt at that moment. Never did I think I would feel any
sort of pride or confidence about my rage as a child. Sitting there with him, however, it really hit me.
I don't want to put words into his mouth, but it sure seemed as though he took comfort in meeting an adult
that not only wasn't punishing him for it, but who could also relate. I will never forget that conversation.
</p>

<p>
Summer camp is a time when you leave your family and friends and meet brand new people. A sort of clean
slate for a week or two. It's all about swimming everyday, songs around a campfire, playing capture the flag
into the dusk and staying up all night playing flashlight tag on the ceiling of your cabin. It's a place of
tie-dye and grass stains, where the people in charge are just big kids and they will listen to the things you
have to say. But at our summer camp we also had tics and extra energy and meds and it all fit in quite naturally.
</p>

<p>
I wish I could describe the amazement and relief that we all shared with each other throughout the week.
Of course, we were not without our quarrels and annoyances with each other, but over all, it was incredible.
As everyone left, there were nothing but good stories and genuine sad goodbyes between the campers. They seemed
to forget about all of the commotion that sometimes came to be and just remembered the fun times when they were
just being kids. Not kids with Tourette Syndrome, not kids with OCD, not kids with ADHD, not kids with
anything- just kids being kids. I, myself, left camp with a surreal feeling about what I had just been a
part of. I had never been in an environment like that before either, and I learned a lot from the campers.
I can still rattle off the names of the seven boys in my cabin in less than three seconds and it is with
great pride that I wear my staff sweatshirt that they all signed. I heard that the dates for next year's
camp session will soon be released, and I can hardly wait! 
<p>

<? pageFooter( $pageInfo ); ?>