# README #

### What is this repository for? ###

* It's a hand crafted version of the web, mostly links with some descriptions. 
Only quality links should be included. Eventually people should be able to navigate around to high quality web pages without using a search engine. It's supposed to be very simple. 
Focus is on content as opposed to pretty layout/graphics. No database back-end, just HTML. 
* I'll get started by including some of my favorite links. Obviously what can be added by one person is limited so I'll need others to contribute. 
* Can be hosted by anyone who has a hosting account, you just push the HTML to the server. 
* [Learn Markdown](https://bitbucket.org/tutorials/markdowndemo)

### How do I get set up? ###
You just do a hg pull and then write simple HTML.
Anyone can add links, people should add stuff based on their own area(s) of expertise and interests.

### Contribution guidelines ###

* Keep it simple and high quality. 

### Who do I talk to? ###

* Repo owner or admin
* I'd like to create a community a bit like wikipedia