# README #

### What is this repository for? ###
* Code files for a simple document management system. 

### How do I get set up? ###
* Needs a web server (e.g. apache) with PHP 5.2 or higher and the PHP sqlite3 PDO driver installed.
* TBD - describe how to bring up the home page. 

### Contribution guidelines ###
* TBD

### Who do I talk to? ###
* TBD