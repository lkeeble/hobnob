<!DOCTYPE html>
<?php
  include_once('Util.php');
  
  $pdo = getPDO();

  if (isset($_POST["action"]) && $_POST["action"] == "redirect") {
    $redirectResourceType = $_POST["redirectResourceType"];
    $redirectResourceId = $_POST["redirectResourceId"];
    
    if ($redirectResourceType == "folder") {
      $folderId = $redirectResourceId;
    } else {
      throw new Exception("Folder redirect handled incorrectly.");
    }
  }  
  elseif (isset($_POST["action"]) && $_POST["action"] == "addFolder") {
      $parentFolderId = $_POST["parentFolderId"];
      $newFolderName = $_POST["newFolderName"];
      createResource($pdo, "folder", $parentFolderId, $newFolderName);
      $folderId = $parentFolderId;
  }
  elseif (isset($_POST["action"]) && $_POST["action"] == "saveDocAndReturn") {
    $docTitle = $_POST["docTitle"];
    $docData = $_POST["docData"];
    $docId = $_POST["id"];
    updateDoc($pdo, $docId, $docTitle, $docData);

    $redirectResourceType = $_POST["redirectResourceType"];
    $redirectResourceId = $_POST["redirectResourceId"];
    
    if ($redirectResourceType == "folder") {
      $folderId = $redirectResourceId;
    } else {
      throw new Exception("Folder redirect handled incorrectly.");
    }
  }
  elseif (isset($_POST["action"]) && $_POST["action"] == "renameResource") {
    $folderId = $_POST['currentFolderId'];
    $resourceName = $_POST['resourceName'];
    renameResource($pdo, $folderId, $resourceName);
  }
  elseif (isset($_POST["action"]) && $_POST["action"] == "deleteResource") {
    $folderId = $_POST['currentFolderId'];
    $documentId = $_POST['documentId'];
    deleteResource($pdo, $documentId);
  }
  elseif (isset($_GET['resourceid'])) {
    $folderId = $_GET['resourceid'];
  }
  else {
    $folderId = null; // root
  }
  
  $folder = getResourceOrNull($pdo, $folderId);
  $resources = getResourcesInFolder($pdo, $folderId);
?>

<html>
  <head>
      <?php include_once('head.php'); ?>
      <title>File Cabinet</title>
  </head>
  <body>
    <form id="mainForm" method="POST">
      
      <input id="redirectResourceType" type="hidden" name="redirectResourceType" />
      <input id="redirectResourceId" type="hidden" name="redirectResourceId" />
      <input id="action" name="action" type="hidden" />
      <input id="parentFolderId" name="parentFolderId" type="hidden" />
      <input id="currentFolderId" name="currentFolderId" type="hidden" />
      <input id="newFolderName" name="newFolderName" type="hidden" />
      <input id="documentId" name="documentId" type="hidden" />
      
      <div id="breadcrumb">
        <?php
          echo "<div id=breadcrumbTrail>";
          echo getBreadcrumbTrail($pdo, $folderId);
          echo "</div>";
          ?>
      </div>
      
      <!--
      <?php if ($folderId != null) { ?>
      <div id="renameResource">
        <input type="text" size="50" id="resourceName" name="resourceName" value="<?php echo $folder['title']; ?>"> <input type="submit" id="btnRenameResource" value="Rename">
      </div>
      <?php } ?>
      -->
      
      <table id="actionTable">
        <tr>
          <td></td>
          <td>
            <input type="submit" id="btnAddDoc" name="btnAddDoc" value="Add Document">
            &nbsp;&nbsp;
            <input type="submit" id="btnAddFolder" name="btnAddFolder" value="Add Folder">
          </td>
        </tr>
      </table>
      
      <?php if (count($resources) == 0) { ?>
        <div id="noResourcesMessage">There are no resources yet in this folder.</div>
      <?php } else { ?>
      <table>
      <?php foreach ($resources as $resource) { 
        echo "<div class='resource'>";
        echo getResourceIconUrl($resource);  
        echo "&nbsp;&nbsp;"; 
        echo getResourceUrl($resource);
        if ($resource['type'] == 'document') {
          echo "&nbsp;&nbsp;";
          echo "<a href='javascript:void(0);' class='delete-anchor inline' documentId='" . $resource['id'] . "'><img class='vertical-align-middle' src='images/icons8/Delete-32.png' /></a>";
          // echo "<input type='submit' value='Delete' class='delete-button' documentId='" . $resource['id'] . "'>"; 
        }          
        echo "</div>";
      } ?>
      </table>
      <?php } ?>
    </form>
    
    <script>
    $(document).ready(init);

    <?php echo redirectViaPostJs(); ?>    
    
    function init() {
      $('#btnAddDoc').click(redirectToAddDoc);
      $('#btnAddFolder').click(addFolder);
      $('#btnRenameResource').click(renameResource);
      $('.delete-anchor').click(deleteResource);
    }
    
  function deleteResource() {
    var response = confirm('Are you sure you want to delete this item?');
    if (! response) {
      return false;
    }
    
    $('#action').val("deleteResource");
    $('#mainForm').attr('action', 'cabinet.php');
    $('#currentFolderId').val('<?php echo $folderId ?>');
    $('#documentId').val($(this).attr('documentid'));
    $('#mainForm').submit();
    return false;
  }
  
  function renameResource() {
    $('#action').val("renameResource");
    $('#mainForm').attr('action', 'cabinet.php');
    $('#currentFolderId').val('<?php echo $folderId ?>');
    $('#mainForm').submit();
    return false;
  }
  
  function redirectToAddDoc() {
    $('#action').val("addDoc");
    $('#parentFolderId').val('<?php echo $folderId; ?>');
    $('#mainForm').attr('action', 'edit.php');
  
    $('#mainForm').submit();
    return false;
  }
  
  function addFolder() {
    var folderName = prompt("Folder name:");
    if (folderName) {
      $('#action').val("addFolder");
      $('#parentFolderId').val('<?php echo $folderId; ?>');
      $('#newFolderName').val(folderName);
      $('#mainForm').attr('action', 'cabinet.php');
      $('#mainForm').submit();
    }
    
    return false;
  }

    </script>

<?php include_once("footer.php"); ?>

  </body>
</html>

<?php 
function resourceLink($resource) {
  if ($resource['type'] == "document") {
    return "(doc) <a href='edit.php?id=" . $resource['id'] . "'>" . $resource['title'] . "</a>";
  }
  else {
    return "(folder) <a href='cabinet.php?folderid=" . $resource['id'] . "'>" . $resource['title'] . "</a>";
  }
}
?>