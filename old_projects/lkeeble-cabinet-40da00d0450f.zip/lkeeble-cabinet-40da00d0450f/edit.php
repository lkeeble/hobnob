<!DOCTYPE html>
<?php

include_once('Util.php');


$pdo = getPDO();

if (isset($_POST["btnSave"])) {
  $id = $_POST["id"];
  $newTitle = $_POST["docTitle"];
  $newData = $_POST["docData"];
  $parentFolder = getParentResourceOrNull($pdo, $id);
  // var_dump($parentFolder);
  // exit();
  updateDoc($pdo, $id, $newTitle, $newData);
  header('Location: cabinet.php?resourceid=' . $parentFolder['id']);
  exit();
} elseif (isset($_POST["action"]) && $_POST["action"] == "addDoc") {
    $parentFolderId = $_POST["parentFolderId"];
    $resource = createResource($pdo, 'document', $parentFolderId, 'New document');
    $id = $resource["id"];
}
elseif (isset($_POST["redirectResourceId"])) {
  $id = $_POST["redirectResourceId"];
}

$resource = getResourceOrNull($pdo, $id);
$parentId = $resource['parentid'];

if ($resource == null) {
  throw new Exception("Resource with id '" . $id . "' was not found.");
}

$docText = $resource['data'];
$docTitle = $resource['title'];
?>

<html>
  <head>
    <?php include_once('head.php'); ?>
    <title>Edit Document</title>
  </head>
  <body>
    <form id="mainForm" method="POST">
      
      <input type="hidden" name="id" value="<?php echo $id;?>">
      <input id="redirectResourceType" type="hidden" name="redirectResourceType" />
      <input id="redirectResourceId" type="hidden" name="redirectResourceId" />
      <input id="action" name="action" type="hidden" />
      <input id="parentFolderId" name="parentFolderId" type="hidden" <?php if (isset($_POST["parentFolderId"])) { echo "value='" . $_POST["parentFolderId"] . "'";} ?> />

      <div id="breadcrumb">
      <?php
          echo "<div id=breadcrumbTrail>";
          echo getBreadcrumbTrail($pdo, $parentId);
          echo "</div>";
        ?>
      </div>

      <table id="actionTable">
        <tr>
          <td></td>
          <td id="submitCell"><input type="submit" id="btnSave" name="btnSave" value="Save">
          </td>
        </tr>
      </table>

      <table id="mainTable">
        <tr>
          <td id="docTitleLabelCell"><strong>Title:</strong></td>
          <td id="docTitleCell"><input id="docTitle" name="docTitle" type="text" value="<?php echo $docTitle ?>" size="50"></input></td>
        </tr>
        <tr>
          <td valign="top"><strong>Text:</strong></td>
          <td valign="top"><textarea id="docData" name="docData" rows="20" cols="100"><?php echo $docText; ?></textarea></td>
        </tr>
      </table>
    </form>

  <script>
    $(document).ready(init);
    
    function init() {
      $('#btnBack').click(function() {
        redirectViaPost('folder', '<?php echo $parentId; ?>');
        return false; 
      });
      setDocLayout();
    }
      
    $(window).resize(function() {
      setDocLayout();
    });
    
    function setDocLayout() {
      // return;
      var mainTableHeight = $(window).height() - 40;
      var docDataHeight = Math.max($(window).height() - 200, 100);
      var docDataWidth = $(window).width() - 40 - $('#docTitleLabelCell').width();
      $('#mainTable').height(mainTableHeight);
      $('#docData').height(docDataHeight);
      $('#docData').width(docDataWidth);
      // $('#docTitle').width(docDataWidth);
    }
    
    <?php echo redirectViaPostJs(); ?>    

  </script>
  
  <?php include_once("footer.php"); ?>

  </body>
</html>
