<?php
// For help with PDO, see https://phpdelusions.net/pdo

function getPDO() {
  $pdo = new PDO('sqlite:cabinet.db');
  $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  
  return $pdo;
}

function getDocData($pdo, $id) {
  $sql = "select * from nodes where id = ?";
  $stmt = $pdo->prepare($sql);
  $stmt->execute(array($id));
  $rows = $stmt->fetchAll();
  
  return $rows[0];
}

function updateDoc($pdo, $id, $title, $data) {
  $nowGMT = getNowGMT();
  $sql = "update nodes set title = ?, data = ?, lastupdate = ? where id = ?";
  $stmt = $pdo->prepare($sql);
  $stmt->execute(array($title, $data, $nowGMT, $id));
}

function renameResource($pdo, $id, $title) {
  $nowGMT = getNowGMT();
  $sql = "update nodes set title = ?, lastupdate = ? where id = ?";
  $stmt = $pdo->prepare($sql);
  $stmt->execute(array($title, $nowGMT, $id));
}

function deleteResource($pdo, $id) {
  $nowGMT = getNowGMT();
  $sql = "delete from nodes where id = ?";
  $stmt = $pdo->prepare($sql);
  $stmt->execute(array($id));
}

function isPost() {
  return ($_SERVER['REQUEST_METHOD'] == 'POST'); 
}

function getNowGMT() {
  list($usec, $sec) = explode(" ", microtime());
  $now = gmdate("Y-m-d\TH:i:s", $sec) . substr($usec, 1, 8); 
  
  return $now;
}

function getResourcesInFolder($pdo, $id) {
  if ( $id != null) {
    $sql = "select * from nodes where parentid = ? order by title";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(array($id));
  } else {
    // echo "finding root level resources";
    // exit(); 
    $sql = "select * from nodes where parentid is null order by title";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
  }
  
  $rows = $stmt->fetchAll();
  
  // echo "rows:";
  // var_dump($rows);
  // exit();
  
  return $rows;
}

function createCabinet($pdo, $cabinetTitle) {
  $cabinet = getCabinetWithTitleOrNull($pdo, $cabinetTitle);
  if ($cabinet !== null) {
    throw new Exception("Attempt to create an already-existing cabinet '" . $cabinetTitle . "'.");
  }
  
  $nowGMT = getNowGMT();
  $sql = "insert into nodes (parentid, type, title, creation, lastUpdate, data) values (null, 'folder', ?, ?, ?, null)";
  
  $stmt = $pdo->prepare($sql);
  $stmt->execute(array($cabinetTitle, $nowGMT, $nowGMT));
}

function createResource($pdo, $type, $parentId, $title) {
  // $resource = getResourceOrNull($pdo, $type, $parentId, $title);
  // if ($resource !== null) {
  //   throw new Exception("Attempt to create an already-existing resource '" . $cabinetTitle . "'.");
  // }
  
  $nowGMT = getNowGMT();
  if ($type == 'document') {
      $sql = "insert into nodes (parentid, type, title, creation, lastUpdate, data) values (?, ?, ?, ?, ?, '')";
  } else if ($type == 'folder') {
    $sql = "insert into nodes (parentid, type, title, creation, lastUpdate, data) values (?, ?, ?, ?, ?, null)";
  }
  
  $stmt = $pdo->prepare($sql);
  $stmt->execute(array($parentId, $type, $title, $nowGMT, $nowGMT));
  
  $lastInsertId = $pdo->lastInsertId();
  
  return getResourceOrNull($pdo, $lastInsertId);
}

function getCabinetWithTitleOrNull($pdo, $cabinetTitle) {
  $sql = "select * from nodes where title = ? and type = 'folder' and parentid is null";
  
  $stmt = $pdo->prepare($sql);
  $stmt->execute(array($cabinetTitle));
  $rows = $stmt->fetchAll();
  
  if (count($rows) == 0) {
    return null;
  }
  
  if (count($rows) > 1) {
    throw new Exception('Found ' . count($rows) . " rows for cabinet '" . $cabinetTitle . "'");
  }
  
  return $rows[0];
}

function getResourceWithTitleOrNull($pdo, $type, $parentId, $title) {
  $sql = "select * from nodes where title = ? and type = ? and parentid is ?";
  
  $stmt = $pdo->prepare($sql);
  $stmt->execute(array($title, $type, $parentId));
  $rows = $stmt->fetchAll();
  
  if (count($rows) == 0) {
    return null;
  }
  
  if (count($rows) > 1) {
    throw new Exception('Found ' . count($rows) . " rows for cabinet '" . $cabinetTitle . "'");
  }
  
  return $rows[0];
}

function getResourceOrNull($pdo, $id) {
 $sql = "select * from nodes where id = ?";
  
  $stmt = $pdo->prepare($sql);
  $stmt->execute(array($id));
  $rows = $stmt->fetchAll();
  
  if (count($rows) == 0) {
    return null;
  }
  
  return $rows[0];
}

function isResourceInCabinet($pdo, $cabinetId, $id) {
  if ($id == $cabinetId) {
    return true;
  }
  
  $loopId = $id;
  $maxTries = 200;
  $loopCounter = 0;
  
  $parentRow = getParent($pdo, $id);
  $parentId = $parentRow['id'];
  
  while ($parent != null) {
    if ($loopCounter > $maxTries) {
      break;
    }
    
    if ($parent['id'] == $cabinetId) {
      return true;
    }
    
    $loopCounter++;
    $parent = getParent($pdo, $parent['id']);
  }
  
  return false;
}

function getParentResourceOrNull($pdo, $id) {
  $sql = "select * from nodes where id = (select parentid from nodes where id = ?)";
  
  $stmt = $pdo->prepare($sql);
  $stmt->execute(array($id));
  $rows = $stmt->fetchAll();
  
  if (count($rows) == 0) {
    return null;
  }
  
  return $rows[0];
}

function getResourceUrl($resource) {
  $type = $resource['type'];
  $id = $resource['id'];
  
  return "<a href=\"javascript:redirectViaPost('" . $type . "', '" . $id . "');\">" . $resource['title'] . "</a>";
}

function getResourceIconUrl($resource) {
  $type = $resource['type'];
  $id = $resource['id'];
  $url = "<a href=\"javascript:redirectViaPost('" . $type . "', '" . $id . "');\">";
  if ($resource['type'] == 'folder') {
      $url = $url . "<img class=\"vertical-align-middle\" src=\"images/icons8/Open Folder-32.png\" />";
  } else {
    $url = $url . "<img class=\"vertical-align-middle\" src=\"images/icons8/Edit File-32.png\" />";
  }
  $url = $url . "</a>";
  
  return $url;
}

// Array starts with cabinet and goes from there. 
function getResourcesPathArr($pdo, $id) {
  // echo "getResourcespathArr id: " . $id . "<br>";
  
  $loopResource = getResourceOrNull($pdo, $id);
  $folderArr = array();
  
  while ($loopResource != null) {
    array_push($folderArr, $loopResource);
    
    if ($loopResource['parentid'] == null) {
      break;
    }    
    $loopResource = getResourceOrNull($pdo, $loopResource['parentid']);
  }
  
  $folderArrReverse = array_reverse($folderArr);
  
  // echo "getResourcesPathArr returning: <br>";
  // var_dump($folderArrReverse);
  
  return $folderArrReverse;
}

function getCabinetForResource($pdo, $id) {
  $folderArr = getResourcesPathArr($pdo, $id);
  
  return $folderArr[0]; 
}

function getBreadcrumbTrail($pdo, $id) {
  $folderArr = getResourcesPathArr($pdo, $id);
  
  $breadcrumb = "<a href='cabinet.php'>Root Folder</a>";
  
  foreach ($folderArr as $folder) {
    $breadcrumb .= " > ";
    $breadcrumb .=  getResourceUrl($folder);
    
    // echo "breadcrumb: " . $breadcrumb;
    $firstItem = false;
  }

  return $breadcrumb;  
}

function getHeader() { 
?>
<img src="filecabinet_header.php">
<?php
}

function redirectViaPostJs() {
?>
function redirectViaPost(type, id) {
  $('#redirectResourceType').val(type);
  $('#redirectResourceId').val(id);
  $('#action').val("redirect");
  
  if (type == 'document') {
    $('#mainForm').attr('action', 'edit.php');  
  } else {
    $('#mainForm').attr('action', 'cabinet.php');  
  }
  
  $('#mainForm').submit();
  return false;
}
<?php  
}
?>
