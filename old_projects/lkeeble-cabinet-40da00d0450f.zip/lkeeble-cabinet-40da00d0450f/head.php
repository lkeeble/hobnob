<meta http-equiv="Content-type" content="text/html; charset=utf-8">
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>
<link rel="stylesheet" href="cabinet.css?v=<?php echo time();?>">
<link rel="stylesheet" href="font-awesome-4.6.3/css/font-awesome.min.css">
<link rel='shortcut icon' href='favicon.ico' type='image/x-icon'/ >
<!-- <img src="filecabinet_header.png"> -->
