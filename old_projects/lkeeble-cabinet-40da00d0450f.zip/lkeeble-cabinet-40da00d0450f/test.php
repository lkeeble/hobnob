<html>
<head>
<title> PHP Test Script </title>
</head>
<body>
<?php
phpinfo( );
?> 
</body>
</html>