# README #
This is a browser-based remake of the classic Breakout game!
It's written in javascript with a tiny bit of jQuery. It uses the HTML5 Canvas tag.

### What is this repository for? ###
* Fun and learning.

### How do I get set up? ###
* Copy files to your local machine. 
* Open game.htm
* Have fun!

### Contribution guidelines ###
* Pull code and modify as needed, or email me and ask for commit privileges. 

### To Do
* BUG: Sometimes the ball passes right through the paddle.
* Angle of ball is changed when the ball hits the paddle while the paddle is in motion. I'm not happy with how this currently works (doesn't feel right). Angle of ball is sometimes weird (too steep/shallow).

### Who do I talk to? ###
* Lou (lkeeble@yahoo.com)