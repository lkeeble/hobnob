# README #

* This is a simple tool for laying out shapes such as rectangles, text, images, on an HTML canvas. 
* Uses mainly javascript and a little bit of jQuery.

To get started, do a pull, then bring up designer.htm in a browser. 

### What is this repository for? ###

### How do I get set up? ###

* See above

### Contribution guidelines ###

* Writing tests - TBD
* Code review - TBD
* Other guidelines - TBD

### Who do I talk to? ###
* Lou Keeble, repo owner