# README #

* This is a simple tool for scribbling. 
* Uses mainly javascript and a little bit of jQuery.

To get started, do a pull, then bring up designer.htm in a browser. 

### What is this repository for? ###

### How do I get set up? ###

* See above

### Contribution guidelines ###

* Writing tests - TBD
* Code review - TBD
* Other guidelines - TBD

### Who do I talk to? ###
* lkeeble@yahoo.com