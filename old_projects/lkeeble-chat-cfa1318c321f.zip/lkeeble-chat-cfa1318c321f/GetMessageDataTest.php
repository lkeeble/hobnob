<html>
<body>
<form action="GetMessageData.php" method="GET">
  <table>
    <tr>
      <td>Board ID:</td>
      <td><input type="text" name="BoardID"></td>
    </tr>
    <tr>
      <td>Client ID:</td>
      <td><input type="text" name="ClientID"size="50"></td>
    </tr>
    <tr>
      <td>handle:</td>
      <td><input type="text" name="handle"></td>
    </tr>
    <tr>
      <td>Begin Date:</td>
      <td><input type="text" name="BeginDate" value="1900-01-01T00:00:00"></td>
    </tr>
    <tr>
      <td colspan="2"><input type="submit" value="Submit"></td>
    </tr>
  </table>
    
</form>
</body>
</html>