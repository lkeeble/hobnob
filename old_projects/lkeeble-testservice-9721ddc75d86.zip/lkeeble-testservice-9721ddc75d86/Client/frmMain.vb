﻿Imports System.ServiceModel
Imports System.ServiceModel.Channels
Imports System.Xml
Imports System.ServiceModel.Description
Imports System.Threading


<CallbackBehavior(ConcurrencyMode:=ConcurrencyMode.Multiple)>
Public Class frmMain
  Implements IMessageCallback

  Private _proxy As ITestService
  Private _isProxyCreated As Boolean
  Private _channelLock As New Object()

  Private Sub btnGo_Click(sender As Object, e As EventArgs) Handles btnGo.Click
    Dim getDataOut As String = _proxy.GetData(CInt(txtInputInteger.Text))
    txtOutputGetDataValue.Text = getDataOut

    Dim getDataUsingDataContractOut As CompositeType = _proxy.GetDataUsingDataContract(New CompositeType() With {.StringValue = txtCompositeStringValue.Text})
    txtOutputCompositeStringValue.Text = getDataUsingDataContractOut.StringValue

  End Sub

  Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles Me.Load
    CreateProxy()
  End Sub

  Private Sub CreateProxy()
    SyncLock _channelLock
      Dim binding As Channels.Binding = CreateTcpBinding()
      ' Note: have to append "tcp" to the end of the URI to get it to work This is the full endpoint string that is listed by the console host when it starts up).
      Dim endpointAddress As New EndpointAddress(New Uri("net.tcp://localhost:3055/Keeble/Service/tcp"), EndpointIdentity.CreateSpnIdentity(String.Empty))

      ' Can use this when we get callbacks working. Until then use ChannelFactory.
      Dim factory As New DuplexChannelFactory(Of ITestService)(New InstanceContext(Me), binding, endpointAddress)
      'Dim factory As New ChannelFactory(Of ITestService)(binding, endpointAddress)

      _proxy = factory.CreateChannel()
      DirectCast(_proxy, IChannel).Open()

      Dim co As ICommunicationObject = DirectCast(_proxy, ICommunicationObject)

      ' TODO implement
      'AddHandler co.Faulted, AddressOf OnChannelFaulted
      'AddHandler co.Opened, AddressOf OnChannelOpened
      'AddHandler co.Opening, AddressOf OnChannelOpening
      'AddHandler co.Closing, AddressOf OnChannelClosing
      'AddHandler co.Closed, AddressOf OnChannelClosed

      _isProxyCreated = True
    End SyncLock
  End Sub

  Private Function CreateTcpBinding() As Channels.Binding
    Dim tcpBinding As New NetTcpBinding(SecurityMode.Transport, True)
    With tcpBinding
      .MaxReceivedMessageSize = 2147483646
      .ReceiveTimeout = TimeSpan.MaxValue
      .SendTimeout = TimeSpan.MaxValue ' New TimeSpan(0, 0, 30)
      .OpenTimeout = New TimeSpan(0, 0, 5)
      .MaxConnections = 1000
      .ReliableSession.InactivityTimeout = New TimeSpan(0, 1, 0)
      .ReliableSession.Ordered = True
    End With

    Dim tcpReaderQuotas As New Xml.XmlDictionaryReaderQuotas()
    tcpReaderQuotas.MaxStringContentLength = 2147483646
    tcpBinding.GetType().GetProperty("ReaderQuotas").SetValue(tcpBinding, tcpReaderQuotas, Nothing)

    Return tcpBinding
  End Function

  Public Sub SendMessage(message As String) Implements IMessageCallback.SendMessage
    txtMessage.Text = message
  End Sub

  Public Function BeginSendMessage(message As String, callback As AsyncCallback, asyncState As Object) As IAsyncResult Implements IMessageCallback.BeginSendMessage
    Return New CompletedAsyncResult(Of String)(message)
  End Function

  Public Sub EndSendMessage(result As IAsyncResult) Implements IMessageCallback.EndSendMessage

  End Sub
End Class
