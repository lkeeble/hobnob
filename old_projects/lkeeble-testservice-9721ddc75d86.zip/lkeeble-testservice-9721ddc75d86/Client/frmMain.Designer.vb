﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
  Inherits System.Windows.Forms.Form

  'Form overrides dispose to clean up the component list.
  <System.Diagnostics.DebuggerNonUserCode()> _
  Protected Overrides Sub Dispose(ByVal disposing As Boolean)
    Try
      If disposing AndAlso components IsNot Nothing Then
        components.Dispose()
      End If
    Finally
      MyBase.Dispose(disposing)
    End Try
  End Sub

  'Required by the Windows Form Designer
  Private components As System.ComponentModel.IContainer

  'NOTE: The following procedure is required by the Windows Form Designer
  'It can be modified using the Windows Form Designer.  
  'Do not modify it using the code editor.
  <System.Diagnostics.DebuggerStepThrough()> _
  Private Sub InitializeComponent()
    Me.lblIntegerValue = New System.Windows.Forms.Label()
    Me.txtInputInteger = New System.Windows.Forms.TextBox()
    Me.lblCompositeStringValue = New System.Windows.Forms.Label()
    Me.txtCompositeStringValue = New System.Windows.Forms.TextBox()
    Me.lblOutputCompositeStringValue = New System.Windows.Forms.Label()
    Me.lblOutputGetDataValue = New System.Windows.Forms.Label()
    Me.txtOutputGetDataValue = New System.Windows.Forms.TextBox()
    Me.txtOutputCompositeStringValue = New System.Windows.Forms.TextBox()
    Me.btnGo = New System.Windows.Forms.Button()
    Me.lblAsyncMessage = New System.Windows.Forms.Label()
    Me.txtMessage = New System.Windows.Forms.TextBox()
    Me.SuspendLayout()
    '
    'lblIntegerValue
    '
    Me.lblIntegerValue.AutoSize = True
    Me.lblIntegerValue.Location = New System.Drawing.Point(13, 13)
    Me.lblIntegerValue.Name = "lblIntegerValue"
    Me.lblIntegerValue.Size = New System.Drawing.Size(142, 13)
    Me.lblIntegerValue.TabIndex = 0
    Me.lblIntegerValue.Text = "Input GetData Integer value:"
    '
    'txtInputInteger
    '
    Me.txtInputInteger.Location = New System.Drawing.Point(161, 10)
    Me.txtInputInteger.Name = "txtInputInteger"
    Me.txtInputInteger.Size = New System.Drawing.Size(145, 20)
    Me.txtInputInteger.TabIndex = 1
    Me.txtInputInteger.Text = "3"
    '
    'lblCompositeStringValue
    '
    Me.lblCompositeStringValue.AutoSize = True
    Me.lblCompositeStringValue.Location = New System.Drawing.Point(16, 42)
    Me.lblCompositeStringValue.Name = "lblCompositeStringValue"
    Me.lblCompositeStringValue.Size = New System.Drawing.Size(143, 13)
    Me.lblCompositeStringValue.TabIndex = 2
    Me.lblCompositeStringValue.Text = "Input Composite string value:"
    '
    'txtCompositeStringValue
    '
    Me.txtCompositeStringValue.Location = New System.Drawing.Point(165, 39)
    Me.txtCompositeStringValue.Name = "txtCompositeStringValue"
    Me.txtCompositeStringValue.Size = New System.Drawing.Size(218, 20)
    Me.txtCompositeStringValue.TabIndex = 3
    Me.txtCompositeStringValue.Text = "Stuff"
    '
    'lblOutputCompositeStringValue
    '
    Me.lblOutputCompositeStringValue.AutoSize = True
    Me.lblOutputCompositeStringValue.Location = New System.Drawing.Point(16, 122)
    Me.lblOutputCompositeStringValue.Name = "lblOutputCompositeStringValue"
    Me.lblOutputCompositeStringValue.Size = New System.Drawing.Size(153, 13)
    Me.lblOutputCompositeStringValue.TabIndex = 4
    Me.lblOutputCompositeStringValue.Text = "Output Composite String value:"
    '
    'lblOutputGetDataValue
    '
    Me.lblOutputGetDataValue.AutoSize = True
    Me.lblOutputGetDataValue.Location = New System.Drawing.Point(16, 93)
    Me.lblOutputGetDataValue.Name = "lblOutputGetDataValue"
    Me.lblOutputGetDataValue.Size = New System.Drawing.Size(115, 13)
    Me.lblOutputGetDataValue.TabIndex = 5
    Me.lblOutputGetDataValue.Text = "Output GetData Value:"
    '
    'txtOutputGetDataValue
    '
    Me.txtOutputGetDataValue.Location = New System.Drawing.Point(161, 86)
    Me.txtOutputGetDataValue.Name = "txtOutputGetDataValue"
    Me.txtOutputGetDataValue.Size = New System.Drawing.Size(218, 20)
    Me.txtOutputGetDataValue.TabIndex = 6
    '
    'txtOutputCompositeStringValue
    '
    Me.txtOutputCompositeStringValue.Location = New System.Drawing.Point(175, 122)
    Me.txtOutputCompositeStringValue.Name = "txtOutputCompositeStringValue"
    Me.txtOutputCompositeStringValue.Size = New System.Drawing.Size(218, 20)
    Me.txtOutputCompositeStringValue.TabIndex = 7
    '
    'btnGo
    '
    Me.btnGo.Location = New System.Drawing.Point(19, 236)
    Me.btnGo.Name = "btnGo"
    Me.btnGo.Size = New System.Drawing.Size(310, 23)
    Me.btnGo.TabIndex = 8
    Me.btnGo.Text = "Get data from server (and init callback channel)"
    Me.btnGo.UseVisualStyleBackColor = True
    '
    'lblAsyncMessage
    '
    Me.lblAsyncMessage.AutoSize = True
    Me.lblAsyncMessage.Location = New System.Drawing.Point(16, 163)
    Me.lblAsyncMessage.Name = "lblAsyncMessage"
    Me.lblAsyncMessage.Size = New System.Drawing.Size(96, 13)
    Me.lblAsyncMessage.TabIndex = 9
    Me.lblAsyncMessage.Text = "Callback message:"
    '
    'txtMessage
    '
    Me.txtMessage.Location = New System.Drawing.Point(121, 163)
    Me.txtMessage.Name = "txtMessage"
    Me.txtMessage.Size = New System.Drawing.Size(218, 20)
    Me.txtMessage.TabIndex = 10
    '
    'frmMain
    '
    Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
    Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
    Me.ClientSize = New System.Drawing.Size(586, 380)
    Me.Controls.Add(Me.txtMessage)
    Me.Controls.Add(Me.lblAsyncMessage)
    Me.Controls.Add(Me.btnGo)
    Me.Controls.Add(Me.txtOutputCompositeStringValue)
    Me.Controls.Add(Me.txtOutputGetDataValue)
    Me.Controls.Add(Me.lblOutputGetDataValue)
    Me.Controls.Add(Me.lblOutputCompositeStringValue)
    Me.Controls.Add(Me.txtCompositeStringValue)
    Me.Controls.Add(Me.lblCompositeStringValue)
    Me.Controls.Add(Me.txtInputInteger)
    Me.Controls.Add(Me.lblIntegerValue)
    Me.Name = "frmMain"
    Me.Text = "Client"
    Me.ResumeLayout(False)
    Me.PerformLayout()

  End Sub
  Friend WithEvents lblIntegerValue As System.Windows.Forms.Label
  Friend WithEvents txtInputInteger As System.Windows.Forms.TextBox
  Friend WithEvents lblCompositeStringValue As System.Windows.Forms.Label
  Friend WithEvents txtCompositeStringValue As System.Windows.Forms.TextBox
  Friend WithEvents lblOutputCompositeStringValue As System.Windows.Forms.Label
  Friend WithEvents lblOutputGetDataValue As System.Windows.Forms.Label
  Friend WithEvents txtOutputGetDataValue As System.Windows.Forms.TextBox
  Friend WithEvents txtOutputCompositeStringValue As System.Windows.Forms.TextBox
  Friend WithEvents btnGo As System.Windows.Forms.Button
  Friend WithEvents lblAsyncMessage As System.Windows.Forms.Label
  Friend WithEvents txtMessage As System.Windows.Forms.TextBox

End Class
