﻿Imports System.ServiceModel
Imports System.ServiceModel.Channels
Imports System.Xml
Imports System.ServiceModel.Description
Imports System.Threading

Module Module1

  Sub Main()
    Dim _service As New TestService()

    Dim baseAddresses As Uri()
    baseAddresses = New Uri(2) {}
    baseAddresses(0) = New Uri("net.tcp://localhost:3055/Keeble/Service/")
    baseAddresses(1) = New Uri("net.pipe://localhost/Keeble/Service/")
    baseAddresses(2) = New Uri("http://localhost:3056/Keeble/Service/")

    Dim _serviceHost As New ServiceHost(_service, baseAddresses)

    Dim tcpBinding As Binding = CreateTcpBinding()
    'Dim tcpBinding As Binding = CreateCustomTcpBinding()

    ' The full address for the TCP binding will be net.tcp://localhost:3055/Keeble/Service/tcp  (final parameter of the AddServiceEndpoint "tcp" is appended).
    ' If the final parm is a relative URL then it will be appended to a matching baseAddress.
    _serviceHost.AddServiceEndpoint("Keeble.ITestService", tcpBinding, "tcp")

    Dim namedPipeBinding As Binding = CreateNamedPipeBinding()
    'Dim namedPipeBinding As Binding = CreateCustomNamedPipeBinding()
    ' If the final parm is a relative URL then it will be appended to a matching baseAddress.
    _serviceHost.AddServiceEndpoint("Keeble.ITestService", namedPipeBinding, "pipe")

    '_service.Startup()
    _serviceHost.Open()

    For Each se As ServiceEndpoint In _serviceHost.Description.Endpoints
      Console.WriteLine(se.Address.ToString)
    Next

    Console.WriteLine("The service is running")

    ' Just to prevent program from exiting so that the service remains hosted.
    While (True)
      Thread.Sleep(1000)
    End While
  End Sub

  Private Function CreateTcpBinding() As Binding
    Dim tcpBinding As New NetTcpBinding(SecurityMode.Transport, True)
    With tcpBinding
      .MaxReceivedMessageSize = 2147483646
      .ReceiveTimeout = TimeSpan.MaxValue
      .MaxConnections = 1000
      .ReliableSession.Ordered = True
      .ReliableSession.InactivityTimeout = TimeSpan.MaxValue
      .SendTimeout = TimeSpan.MaxValue
    End With
    Dim tcpReaderQuotas As New XmlDictionaryReaderQuotas()
    tcpReaderQuotas.MaxStringContentLength = 2147483646
    tcpBinding.GetType().GetProperty("ReaderQuotas").SetValue(tcpBinding, tcpReaderQuotas, Nothing)

    Return tcpBinding
  End Function

  Private Function CreateNamedPipeBinding() As Binding
    Dim namedPipeBinding As New NetNamedPipeBinding(NetNamedPipeSecurityMode.Transport)
    With namedPipeBinding
      .MaxReceivedMessageSize = 2147483646
      .ReceiveTimeout = TimeSpan.MaxValue
      .MaxConnections = 1000
      .SendTimeout = TimeSpan.MaxValue
    End With
    Dim namedPipeReaderQuotas As New XmlDictionaryReaderQuotas()
    namedPipeReaderQuotas.MaxStringContentLength = 2147483646
    namedPipeBinding.GetType().GetProperty("ReaderQuotas").SetValue(namedPipeBinding, namedPipeReaderQuotas, Nothing)

    Return namedPipeBinding
  End Function

  Private Function CreateHttpBinding() As Binding
    Dim httpBinding As New BasicHttpBinding(BasicHttpSecurityMode.None)

    Return httpBinding
  End Function

End Module
