﻿Imports System.Threading

' NOTE: You can use the "Rename" command on the context menu to change the class name "Service1" in both code and config file together.
<ServiceBehavior(ConcurrencyMode:=ConcurrencyMode.Multiple, InstanceContextMode:=InstanceContextMode.Single)>
Public Class TestService
  Implements ITestService

  Private WithEvents _timer As New Timers.Timer(1000)
  Private Shared _count As Integer = 0
  Private _callbackChannel As IMessageCallback = Nothing

  Public Sub New()
    _timer.Start()

  End Sub

  Public Function GetData(ByVal value As Integer) As String Implements ITestService.GetData
    ' Save callback channel so that it can be re-used for callbacks triggered internally by a Timer.
    _callbackChannel = OperationContext.Current.GetCallbackChannel(Of IMessageCallback)()

    Return String.Format("Thread: " & Thread.CurrentThread.ManagedThreadID & " Input Integer: {0}", value)
  End Function

  Public Function GetDataUsingDataContract(ByVal composite As CompositeType) As CompositeType Implements ITestService.GetDataUsingDataContract
    If composite Is Nothing Then
      Throw New ArgumentNullException("composite")
    End If
    Return New CompositeType() With {.StringValue = "Thread: " & Thread.CurrentThread.ManagedThreadId & " Composite string value: " & composite.StringValue}
  End Function

  Public Sub SendMessageSynchronously(message)
    If _callbackChannel Is Nothing Then Return

    If CType(_callbackChannel, ICommunicationObject).State = CommunicationState.Opened Then
      'callback.BeginSendMessage("hello async from service!", )
      _callbackChannel.SendMessage(message)
    End If
  End Sub

  Public Sub SendMessageAsync(message)
    If _callbackChannel Is Nothing Then Return

    If CType(_callbackChannel, ICommunicationObject).State = CommunicationState.Opened Then
      _callbackChannel.BeginSendMessage(message, AddressOf OnSendMessageAsyncComplete, Me)
    End If
  End Sub

  Private Sub OnSendMessageAsyncComplete(result As IAsyncResult)
    _callbackChannel.EndSendMessage(result)
  End Sub

  Private Sub _timer_Elapsed(sender As Object, e As Timers.ElapsedEventArgs) Handles _timer.Elapsed
    _timer.Stop()
    Dim message As String = "Thread: " & Thread.CurrentThread.ManagedThreadId & " Service count: " & _count
    SendMessageAsync(message)
    'SendMessageSynchronously(message)
    _count = _count + 1
    _timer.Start()
  End Sub
End Class
