﻿' NOTE: You can use the "Rename" command on the context menu to change the interface name "IService1" in both code and config file together.
<ServiceContract(SessionMode:=SessionMode.Required, CallbackContract:=GetType(IMessageCallback))>
Public Interface ITestService

  <OperationContract()>
  Function GetData(ByVal value As Integer) As String

  <OperationContract()>
  Function GetDataUsingDataContract(ByVal composite As CompositeType) As CompositeType

  ' Could be used to trigger service messages. Needs to have IsOneWay:=True or else hangs the client I guess due to trying to go both ways (?)
  ' Instead of this way we now use a timer to send messages.
  '<OperationContract(IsOneWay:=True)>
  'Sub TriggerMessageFromServer()
End Interface

' Use a data contract as illustrated in the sample below to add composite types to service operations.

<DataContract()>
Public Class CompositeType

  <DataMember()>
  Public Property StringValue() As String

End Class
