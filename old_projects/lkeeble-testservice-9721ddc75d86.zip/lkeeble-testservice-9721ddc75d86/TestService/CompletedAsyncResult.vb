﻿Public Class CompletedAsyncResult(Of T)
  Implements IAsyncResult
  Private data_Renamed As T

  Public Sub New(ByVal data As T)
    Me.data_Renamed = data
  End Sub

  Public ReadOnly Property Data() As T
    Get
      Return data_Renamed
    End Get
  End Property

#Region "IAsyncResult Members"
  Public ReadOnly Property AsyncState() As Object Implements IAsyncResult.AsyncState
    Get
      Return CObj(data_Renamed)
    End Get
  End Property

  Public ReadOnly Property AsyncWaitHandle() As Threading.WaitHandle Implements IAsyncResult.AsyncWaitHandle
    Get
      Throw New Exception("The method or operation is not implemented.")
    End Get
  End Property

  Public ReadOnly Property CompletedSynchronously() As Boolean Implements IAsyncResult.CompletedSynchronously
    Get
      Return True
    End Get
  End Property

  Public ReadOnly Property IsCompleted() As Boolean Implements IAsyncResult.IsCompleted
    Get
      Return True
    End Get
  End Property
#End Region
End Class