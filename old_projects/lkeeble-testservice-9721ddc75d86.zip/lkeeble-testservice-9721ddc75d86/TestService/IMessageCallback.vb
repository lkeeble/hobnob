﻿Public Interface IMessageCallback
  ' Use the following to send Async
  <OperationContract(IsOneway:=True, AsyncPattern:=True)>
  Function BeginSendMessage(message As String, callback As AsyncCallback, asyncState As Object) As IAsyncResult
  Sub EndSendMessage(result As IAsyncResult)

  ' Call the following directly to send non-async. 
  ' (When sent async this still gets called but not directly)
  <OperationContract(IsOneWay:=True)>
  Sub SendMessage(message As String)
End Interface
